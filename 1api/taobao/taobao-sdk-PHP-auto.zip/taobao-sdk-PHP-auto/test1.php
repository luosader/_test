<?php

header("Content-type: text/html; charset=utf-8");

include "TopSdk.php";

//将下载SDK解压后top里的TopClient.php第8行$gatewayUrl的值改为沙箱地址:http://gw.api.tbsandbox.com/router/rest,

//正式环境时需要将该地址设置为:http://gw.api.taobao.com/router/rest

 

//实例化TopClient类

$c = new TopClient;

$c->appkey = "23301207";

$c->secretKey = "fd45c18bc4aa3908444911711de26e6d";

$sessionkey= "sandboxbc4aa3908444911711de26e6d";   //如沙箱测试帐号sandbox_c_1授权后得到的sessionkey

//实例化具体API对应的Request类

$req = new UserSellerGetRequest;

$req->setFields("nick,user_id,type");

//$req->setNick("sandbox_c_1");

 

//执行API请求并打印结果

$resp = $c->execute($req,$sessionkey);

echo "result:";

print_r($resp);

?>