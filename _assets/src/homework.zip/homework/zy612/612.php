<?php
header('Content-Type:text/html;charset=UTF-8');
//作业 输入三个人的三门课的总分，平均分，再将学生按照总分排序(倒序)，平均分排序(正序);
//建立一个数组，随机生成一个验证码
//验证码:

echo "<table border='1' >";
$arr1 = array('语文：' => mt_rand(45,90),'数学' => mt_rand(10,70),'英语' => mt_rand(10,70));
$arr2 = array('语文：' => mt_rand(67,100),'数学' => mt_rand(67,100),'英语' => mt_rand(67,100));
$arr3 = array('语文：' => mt_rand(56,87),'数学' => mt_rand(56,87),'英语' => mt_rand(56,87));
echo  "<tr>"."<td>".'李：'."</td>";
foreach ( $arr1  as  $key  =>  $val ) {
	echo "<td>";
    echo  " $key  =  $val ".'<br>';
    echo "</td>";
}
echo "</tr>";
echo  "<tr>"."<td>".'小：'."</td>";
foreach ( $arr2  as  $key  =>  $val ) {
	echo "<td>";
    echo  " $key  =  $val ".'<br>';
    echo "</td>";
}
echo "</tr>";
echo  "<tr>"."<td>".'龙：'."</td>";
foreach ( $arr3  as  $key  =>  $val ) {
	echo "<td>";
    echo  " $key  =  $val ".'<br>';
    echo "</td>";
}
echo "</tr>".'</table>'.'<br>';

echo "<table border='1' >";
$a=array('李' => array_sum($arr1),'小' => array_sum($arr2),'龙' => array_sum($arr3));
arsort($a);
	echo "<tr>".'<td>';
	echo "总分降序排列：".'<br>';
	echo "</td>";
foreach ( $a  as  $key  =>  $val ) {
	echo "<td>";
    echo  " $key  =  $val ".'<br>';
    echo "</td>";
}
echo "</tr>".'<tr>';
$x=round (array_sum($arr1)/3,2);$y=round (array_sum($arr3)/3,2);$z=round (array_sum($arr3)/3,2);
$b = array('李' => $x,'小' => $y,'龙' => $z);
asort($b);
	echo "<td>";
	echo "平均分正序排列：".'<br>';
	echo "</td>";
foreach ( $b  as  $key  =>  $val ) {
	echo "<td>";
    echo  " $key  =  $val ".'<br>';
    echo "</td>";
}
echo "</tr>".'</table>';

?>