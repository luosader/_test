<?php
header('Content-Type:text/html;charset=UTF-8');
//作业 输入三个人的三门课的总分，平均分，再将学生按照总分排序(倒序)，平均分排序(正序);
//建立一个数组，随机生成一个验证码
//验证码:
/*

*/
echo "请刷新";
echo "<table border='1' bgcolor='#0992f1'>";
$arr1 = array('语文' => mt_rand(77,100),'数学' => mt_rand(17,67),'英语' => mt_rand(77,100));
$arr2 = array('语文' => mt_rand(67,100),'数学' => mt_rand(67,100),'英语' => mt_rand(67,100));
$arr3 = array('语文' => mt_rand(47,77),'数学' => mt_rand(77,100),'英语' => mt_rand(27,67));
echo  "<tr>"."<td>".'李：'."</td>";
foreach ( $arr1  as  $key  =>  $val ) {
    echo "<td>";
    echo  " $key  =  $val ".'<br>';
    echo "</td>";
}
echo "</tr>";
echo  "<tr>"."<td>".'小：'."</td>";
foreach ( $arr2  as  $key  =>  $val ) {
    echo "<td>";
    echo  " $key  =  $val ".'<br>';
    echo "</td>";
}
echo "</tr>";
echo  "<tr>"."<td>".'龙：'."</td>";
foreach ( $arr3  as  $key  =>  $val ) {
    echo "<td>";
    echo  " $key  =  $val ".'<br>';
    echo "</td>";
}
echo "</tr>".'</table>'.'<br>';

echo "<table border='1' bgcolor='#87CEEB'>";
$a=array('李' => array_sum($arr1),'小' => array_sum($arr2),'龙' => array_sum($arr3));
arsort($a);
    echo "<tr>".'<td>';
    echo "总分降序排列：".'<br>';
    echo "</td>";
foreach ( $a  as  $key  =>  $val ) {
    echo "<td>";
    echo  " $key  =  $val ".'<br>';
    echo "</td>";
}
echo "</tr>".'<tr>';
$x=round (array_sum($arr1)/3,2);$y=round (array_sum($arr3)/3,2);$z=round (array_sum($arr3)/3,2);
$b = array('李' => $x,'小' => $y,'龙' => $z);
asort($b);
    echo "<td>";
    echo "平均分正序排列：".'<br>';
    echo "</td>";
foreach ( $b  as  $key  =>  $val ) {
    echo "<td>";
    echo  " $key  =  $val ".'<br>';
    echo "</td>";
}
echo "</tr>".'</table>'.'<br>';

echo '<hr>'.'<br>';

echo "<table border='1' bgcolor='#AFEEEE'>";
echo '<tr>';
echo "<td width='160' align='center'>".'验证码方法1：'."</td>";
echo "<td width='160' align='center'>".'验证码方法2：'."</td>";
echo "<td width='160' align='center'>".'验证码方法3：'."</td>";
echo "<td width='160' align='center'>".'验证码方法4：'."</td>";
echo "<td width='160' align='center'>".'验证码方法5：'."</td>";
echo "</tr>";
//第一种验证码
$arr4 = array(rand(0,1000000));
echo '<tr>'."<td width='160' align='center'>";
echo implode ( '; ' ,  $arr4);
echo '</td>';
//第二种验证码
$arr5 = array(0,1,2,3,4,5,6,7,8,9,'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
$c = array_rand($arr5,6);
echo "<td width='160' align='center'>";
foreach($c as $key){echo $arr5[$key];}
echo '</td>';
//第三种验证码
$arr6  = array(0,1,2,3,4,5,6,7,8,9,'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
$rand_keys  =  array_rand ( $arr6 ,  6 );
echo "<td width='160' align='center'>";
echo  $arr6 [ $rand_keys [ 0 ]];
echo  $arr6 [ $rand_keys [ 1 ]];
echo  $arr6 [ $rand_keys [ 2 ]];
echo  $arr6 [ $rand_keys [ 3 ]];
echo  $arr6 [ $rand_keys [ 4 ]];
echo  $arr6 [ $rand_keys [ 5 ]];
echo '</td>';
//第四种验证码
echo "<td width='160' align='center'>";
function random($len) {
    $srcstr="ABCDEFGHIJKLMNPQRSTUVWXYZ1234567890";
    //mt_rand();
    $strs="";
    for($i=0;$i<$len;$i++) {
        $strs.=$srcstr[mt_rand(0,33)];
    }
    return ($strs);
}
$str=random(4); //随机生成的字符串
echo $str;
echo '</td>';
//第五种验证码
echo "<td width='160' align='center'>";
function verify($len) {
    $str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890';
    $a = "";
    for($j=0;$j<$len;$j++) {
        $a .= substr($str, mt_rand(0,61),1);
        // $a .= substr($str, mt_rand(0,strlen($str)),1);
    }
    return $a;
}
echo verify(5); //随机生成的字符串数目
echo '</td>';

echo "</tr>".'</table>';

?>