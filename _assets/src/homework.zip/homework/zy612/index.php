﻿<?php
echo "<table border='1' >";
echo '<tr>';
echo "<td width='160' align='center'>".'验证码方法1：'."</td>";
echo "<td width='160' align='center'>".'验证码方法2：'."</td>";
echo "<td width='160' align='center'>".'验证码方法3：'."</td>";
echo "</tr>";

$arr4 = array(rand(0,1000000));
echo '<tr>'."<td width='160' align='center'>";
echo implode ( '; ' ,  $arr4);
echo '</td>';
$arr5 = array(0,1,2,3,4,5,6,7,8,9,'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
$c = array_rand($arr5,6);
echo "<td width='160' align='center'>";
foreach($c as $key){echo $arr5[$key];}
echo '</td>';
$arr6  = array(0,1,2,3,4,5,6,7,8,9,'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
$rand_keys  =  array_rand ( $arr6 ,  6 );
echo "<td width='160' align='center'>";
echo  $arr6 [ $rand_keys [ 0 ]];
echo  $arr6 [ $rand_keys [ 1 ]];
echo  $arr6 [ $rand_keys [ 2 ]];
echo  $arr6 [ $rand_keys [ 3 ]];
echo  $arr6 [ $rand_keys [ 4 ]];
echo  $arr6 [ $rand_keys [ 5 ]];
echo '</td>';

echo "</tr>".'</table>';
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	<title>三维数组取值</title>
	<style type="text/css">
	html,body,form,input,select,p,div,span{margin:0px;padding:0px;font-size: 18px;}
		.div{width:900px;height:auto;overflow:hidden;margin:20px auto;}
		.th{float:left;width:500px;}
		form{float:left;width:300px;height:auto;overflow:hidden;margin-top: 100px;}
		p{float:left;width:300px;}
		.js{float:left;border: 1px solid #CCC;}
		input{float:left;width:60px;height:40px;margin-right: 8px;margin-top: 15px;text-align: center;}
		span{float:left;width:auto;min-width:100px;height:38px;margin-left: 8px;margin-top:15px;border: 1px solid #CCC;text-align: center;line-height: 40px;}
	</style>
	<script src="js/jquery-1.11.0.min.js"></script>
</head>
<body>
	<div class="div">
		<div class="th"></div>
		<form id="form" action="array_search.php" name="数组" method="post">
			<p>请输入要获取的位置：(每个框输入0~2之间的数字)</p>
			<input class="js" type="text" name="num1" maxlength="1">
			<input class="js" type="text" name="num2">
			<input class="js" type="text" name="num3">
			
			<input type="button" onclick="$(this).sub()" value="替换">
			<!--如果用submit，则跳转到另一个页面-->
			<span></span>
		</form>
	</div>
	<script type="text/javascript">
	$(function(){
		jQuery.fn.sub = function(){
			var str = $(".js").map(function(){
				return ($(this).attr("name")+"="+$(this).val());
			}).get().join("&");
			$.ajax({
				type:"POST",//即form中的method
				url:"array_search.php",
				data:str,
				success:function(msg){
				$("span").text(msg);
				}
			});
		}
	})
	
	</script>
</body>
</html>