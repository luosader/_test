﻿<?php
header('Content-Type:text/html;charset=UTF-8');
	$arr = array(array('title'=>'第一个文章标题','author'=>'admin','time'=>'1434077500','content'=>'你好！欢迎使用本贴吧。','href'=>'http://www.imooc.com'),array('title'=>'第二个文章标题','author'=>'张三','time'=>'1434070500','content'=>'慕课网-国内最大的IT技能学习平台。慕课网是垂直的互联网IT技能免费学习网站。以独家视频教程、在线编程工具、学习计划、问答社区为核心特色。在这里，你可以找到最好的互联网技术牛人，也可以通过免费的在线公开视频课程学习国内领先的互联网IT技术。慕课网课程涵盖前端开发、PHP、Html5、Android、iOS、Swift等IT前沿技术语言，包括基础课程、实用案例、高级分享三大类型，适合不同阶段的学习人群。以纯干货、短视频的形式为平台特点，为在校学生、职场白领提供了一个迅速提升技能、共同分享进步的学习平台。4月2日，国内首个IT技能学习类应用——慕课网3.1.0版本在应用宝首发。据了解，在此次上线的版本中，慕课网新增了课程历史记录、相关课程推荐等四大功能，为用户营造更加丰富的移动端IT学习体验。','href'=>'http://www.imooc.com'),array('title'=>'第三个文章标题','author'=>'游客','time'=>'1434066500','content'=>'你好！','href'=>'about:cehome'),array('title'=>'第四个文章标题','author'=>'李四','time'=>'1434065500','content'=>'你好！','href'=>'about:cehome'),array('title'=>'第五个文章标题','author'=>'王麻子','time'=>'1434056500','content'=>'你好！','href'=>'about:cehome'),array('title'=>'第六个文章标题','author'=>'游客','time'=>'1434055500','content'=>'你好！','href'=>'about:cehome'),array('title'=>'第七个文章标题','author'=>'游客','time'=>'1434046500','content'=>'你好！','href'=>''),array('title'=>'第八个文章标题','author'=>'游客','time'=>'1433966500','content'=>'你好！','href'=>''),array('title'=>'第九个文章标题','author'=>'游客','time'=>'1433066500','content'=>'你好！','href'=>''));
	$rep = str_repeat("&nbsp",30);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Html中遍历数组</title>
<link rel="shortcut icon" href="img/Cat Portrait(64x64).jpg">
<link rel="stylesheet" type="text/css" href="css/icon.css" />
<style>
    body,html,div,span,p,img,ul,li,a,form,input,h3{margin:0;padding:0;font-family:"宋体";font-size:14px;text-decoration:none;}
	.div-img{ opacity:1;}
	.div-img:hover{ opacity:0.7;}
	body{background-color:#c0c6fF; }
	/*-------------------------------------------总体布置----------------------------------------------------------*/
	.line{width:100%;height:40px;border-bottom:#999 solid 1px;background-image:linear-gradient(to bottom,#fff,#B0EAEA);
		box-shadow:0px 1px 4px rgba(204,204,204,0.6);position:fixed;z-index:3;top:0px;}
	.topmain{width:1000px;height:40px;padding:0px;margin:0px auto;}
	.top1{display:block;width:100px;text-align:center;line-height:40px;}
	.top1 p{width:100px;font-size:12px;font-family:"微软雅黑";position:fixed;z-index:4;}
	.nav{width:100px;list-style:none;padding: 40px 0px 0px 0px;margin:0px;background:#fff;box-shadow:0px 0px 5px #999;display:none;position:fixed;z-index:2;}
	.top1:hover ul{display:block;}
	.nav li a{height:29px;width:80px;margin:0px auto;line-height:29px;display:block;}
	.li-bottom{border-bottom:1px dotted #999;}
	.nav li:hover{background-color:#eee;}
	#shoucang{width:100px;margin-left:100px;}
	.top1-2{float:right;width:80px;height:40px;display:block;text-align:center;margin:0px auto;overflow:hidden;}
	.denglu{background-color: #2B8723;;color:white;width:80px;display:block;height:30px;padding:11px 0px 0px 0px;
		font-family:"微软雅黑";}
	.denglu:hover{background-color: #16BC0F;color:white;}
	.zhuce{width:80px;height:29px;padding:11px 0px 0px 0px;}
	.zhuce-a{font-family:"微软雅黑";}
	.load{float:right;}
	.yh{width:25px;height:25px;border-radius:3px;margin:7px auto;}
	.yh1{padding:11px 0px 0px 0px;width:50px;}
	.yh2{font-family:"微软雅黑";font-size:12px;}
   /*-----------------------------------------上面是导航栏-----高40------------------------------------------*/
    .zong{ width:1000px; height: auto;overflow: hidden; margin:42px auto;background-color:#c3e6fF;}
	.cont{float: left;width:1000px; height: auto;overflow: hidden;}
	.top2{ width:1000px; height:80px;border-bottom:4px #2B8723 solid;}
	.lvyoulogo{ float:left; padding:20px 0px 0px 0px;}
	.nbv{ list-style:none;  padding:30px 0px 0px 0px;}
	.nbv ul{ list-style:none;  }
	.nbv-li{width:100px; height:40px; text-align:center; float:right;display:block;}
	.nbv-li:hover ul{ display:block;}
	.nbv-name:hover{ background-color: #4DC53A; color:white; text-decoration:none;display:block;}
	.nbv-name{ font-size:18px; font-family:"微软雅黑"; width:100px; display:block; height:40px; line-height:40px; position: relative; z-index:2;}
	.nbv-name span{ margin-right:5px;}
    .nbv-ul a:hover{ color:white; background-color:#4DC53A; text-decoration:none; display:block;}
	.nbv-ul{box-shadow:0px 1px 4px rgba(204,204,204,0.6); display:none; padding-top:40px;
	        position: relative; z-index:1; margin-top:-40px;}
	.nbv-ul li{ width:98px; height:30px; line-height:30px;background-color:#fff;}
	.nbv-ul a{ font-family:"微软雅黑"; display:block;}
	/*------------------------------------上面是页面主菜单-----高124-----------------------------------------*/
	.sou{ float:left;width:998px; height: auto;overflow: hidden;border-left: 1px solid #999;border-right: 1px solid #999;}
	.sou1{float:left;width:588px; height: 40px;text-align: left;line-height: 40px;padding-left: 10px;}
	.sou1 a{font-family: 'Microsoft Yahei';font-size: 12px;}
	.sou-link2{color:#009241;}
	.sou2{float:right;width:210px; height: 40px;}
	.form1{margin-top:2px;}
	.submit1{float:left;padding:3px;color:#FFF;background:#009241;font-family: 'Microsoft Yahei'; font-size: 14px;border-radius:19px;}
	.text1{float:left;width:150px;height: 26px;margin-top:2px;text-align:center;border-radius:19px;border:1px #999 solid;}
	/*------------------------------------上面是顶部的搜索框-----高40-----------------------------------------*/
	.leftzong{ float:left; width:749px;border-left: 1px solid #999;border-bottom: 1px solid #999;}
	.content1{ float:left;width:749px; height:39px;border-top:1px #999 solid;}
	.title1{  float:left; padding:11px 25px; color:#000; background-color:#DDD;border-right:1px #999 solid;}
	.title1:hover{color:#FFF;background-color:#BBB;}
	/*------------------------------------左上面是第一部分内容--------------------------------------------------*/
	.content2{ float:left;width:748px; height:auto; overflow:hidden;padding-top:1px;border-bottom:1px #999 solid;background-color:#b3e6fF;}
	.content2-1{ float:left;width:710px;height:auto;overflow:hidden;margin:0px 1px 1px 1px;padding:20px;border-top: 1px solid #999;border-bottom: 1px solid #999;background-color:#a3e6fF;}
	.post{border:1px solid #999;margin-bottom:20px; padding: 20px;}
	.post:hover{background-color: #CCf;}
	.content2-2{ float:right;width:600px;height:auto;overflow:hidden;padding:20px 0px;}
	.content2-2 a{float:left;width: 55px;height:30px;margin-right:5px;display: block;}
	.content2-2 a:hover{background-color: #0f0;text-align: center;line-height: 30px;font-size: 16px;font-weight: bold;}
	/*-----------------------------------左上面是第二部分------------------------------------------------------*/
	.publish{ float:left;width:748px;height:auto;overflow:hidden;margin: 10px 0px 10px 20px;}
	.publish p{float:left;width:700px;margin: 10px;}
	.publish textarea{float:left;width:668px;height:180px;margin: 10px;padding: 5px;}
	.publish input{float:left;margin: 10px;}
	.text2{width: 300px;height:30px;text-align: center;line-height: 30px;}
	.button1{}
	/*-----------------------------------左上面是第三部分------------------------------------------------------*/




	.rightzong{ float:left;width:248px; height:auto;overflow: hidden;border:1px solid #999;}
	.cont1{ float:left;width:250px; height:auto;overflow: hidden;min-height: 1516px;}
	/*-----------------------------------右边1----------------------------------------------------------------*/

	/*----------------------------------右边2----------------------------------------------------------------*/

   /*-------------------------------------------------------------------------------------------------------------*/

   /*--------------------------------------------------------------------------------------------------------------*/

   /*----------------------------------------------右搜索部分----------------------------------------------------*/
  .footer{ float:left;width:998px; height: auto; margin:0px auto;border:1px #999 solid; border-top: none;}
  .footer-img{ width:959px; height: auto; border-bottom:1px #999 solid; padding:20px 20px 15px 20px;
       margin-bottom:20px; }
  .footer-img img{ width:960px; height:100px; }
  .footer-word{ width:1000px; height:80px;}
  .footer-word a{ font-size:12px; color:#666;}
  .footer-word a:hover{ color:blue; text-decoration:underline;}
  .footer-word p{ font-size:12px; text-align:center;}
  /*------------------------------------------------上面是底部------------------------------------------------------*/
</style>
</head>
<body>
   <div class="line"><!--置顶框开始-->
      <div class="topmain">
          <div class="top1">
            <p style="cursor:default">
            <span class="icon-bars"></span>
            <span>快速导航</span>
            </p>
            <ul class="nav">
               <li style="border-top:1px #999 solid;"><a class="yh2 li-bottom" href="">首页</a></li>
               <li><a class="yh2 li-bottom" href="">旅游</a></li>
               <li><a class="yh2 li-bottom" href="">景点</a></li>
               <li><a class="yh2 li-bottom" href="">交流</a></li>
               <li><a class="yh2" href="">帮助</a></li>
            </ul>
          </div>
          <div class="top1">
            <p id="shoucang">
            <span><a class="yh2" href="">加入收藏</a></span>
            </p>
          </div>
          <div class="load">
            <span  class="top1-2 zhuce"><a  class="zhuce-a" href="用户注册页.html">注册</a></span>          
            <span  class="top1-2"><a class="denglu" href="用户登录页.html">登录</a></span> 
          </div>
          <div class="load">
           <span  class="top1-2 yh1"><a  class="yh2" href="">退出</a></span>
           <span  class="top1-2 yh1"><a  class="yh2" href="">luosa</a></span>
           <a href=""><img src="img/user.png" class="yh" ></a>
           
          </div>
      </div>         
   </div> <!--置顶框结束-->
   <!--==================================================================================-->
<div class="zong">
	<div class="cont">
	    <div class="top2"><!--页面菜单开始-->
	      <a href=""><img  class="lvyoulogo div-img" src="img/logo.png"></a>
	      <ul class="nbv">
	          <li class="nbv-li">              
	              <a class="nbv-name" href=""><span class="icon-flag"></span>帮助</a>
	              <ul class="nbv-ul">
	                <li><a href="">关于我们</a></li>
	                <li><a href="">联系我们</a></li>
	                <li><a href="">意见反馈</a></li>
	                <li><a href="">投诉举报</a></li>
	              </ul>
	          </li>
	          <li class="nbv-li">              
	              <a class="nbv-name" href=""><span class="icon-group (alias)"></span>交流</a>
	              <ul class="nbv-ul">
	                <li><a href="">全部</a></li>
	                <li><a href="">精品</a></li>
	              </ul>
	          </li>
	          <li class="nbv-li">              
	              <a class="nbv-name" href=""><span class="icon-institution (alias)"></span>景点</a>
	              <ul class="nbv-ul">
	                 <li><a href="">国内</a></li>
	                 <li><a href="">国外</a></li>
	              </ul>
	          </li>
	          <li class="nbv-li">              
	              <a class="nbv-name" href=""><span class="icon-plane"></span>旅游</a>
	              <ul class="nbv-ul">
	                 <li><a href="">亚洲</a></li>
	                 <li><a href="">欧洲</a></li>
	                 <li><a href="">非洲</a></li>
	                 <li><a href="">南美洲</a></li>
	                 <li><a href="">北美洲</a></li>
	                 <li><a href="">大洋洲</a></li>
	              </ul>
	          </li>
	          <li class="nbv-li">             
	              <a class="nbv-name" href=""><span class="icon-home"> </span>首页</a>
	          </li>
	      </ul>   
	    </div><!--页面菜单结束--><!--============================================================================================-->
	    <div class="sou">
	        <div class="sou1">
	         <a href="">主页></a><a class="sou-link2" href="">交流</a>
	         </div>
	         <div class="sou2">
	            <form class="form1">
	               <input  class="text1" type="text" name="" placeholder="请输入关键字">
	               <input  class="submit1" type="submit" name="" value="搜索" style="cursor:pointer">
	            </form> 
	        </div>
	    </div>
	<!--============================================================================================-->
	    <div class="leftzong"><!--左总开始-->
	        <div class="content1"><!--左一开始-->
	            <div><a class="title1" href="">全部</a></div>
	            <div><a class="title1" href="">精品</a></div>
	        </div><!--左一结束-->
	        <div class="content2"><!--左二开始-->
	            <div class="content2-1">
					<?php foreach ($arr as $v) {?>
	                <div class="post">
		                <h3 style="margin:3px;"><?php echo  $v['title'] ?></h3>
		                <p><?php echo '作者：'.$v['author']; echo $rep; //print_r($rep) ?><?php echo '发表日期：'.date('Y-m-d H:i:s',$v['time']) ?></p>
		                <p style="margin:15px 0px 30px 0px;text-indent:2em;"><?php echo $v['content']; echo $rep ?><a target="_blank" href="<?php echo $v['href']?>">相关链接</a></p>
	                </div>
	                <?php } ?>
	            </div>
	            <div class="content2-2">
	                <a href="">首页</a>
	                <a href="">上一页</a>
	                <a href="">1</a>
	                <a href="">2</a>
	                <a href="">3</a>
	                <a href="">4</a>
	                <a href="">5</a>
	                <a href="">6</a>
	                <a href="">下一页</a>
	                <a href="">尾页</a>
	            </div>
	        </div> <!--左二结束--> 
	        <div class="publish"><!--左三开始--> 
	        	<p>发表主题</p>
	        	<input class="text2" type="text" placeholder="请输入标题">
	        	<textarea placeholder="请输入内容"></textarea>
	        	<input class="button1" type="button" value="发表">
	        </div>    <!--左三结束--> 
	    </div><!--左总结束-->
	   <!--
	   -->
	   <div class="rightzong"><!--右边总体开始-->
	     <div class="cont1">
	     	未完待续...
	     </div>
	   </div>            <!--右边总体结束-->
   </div>

  <div class="footer">
   <div class="footer-img">
      <a href=""><img src="img/guanggao.jpg"></a>
   </div>
   <div class="footer-word">
     <p>友情链接：<a href="">百度</a><span>|</span><a href="">携程</a><span>|</span><a href="">百度旅游</a> </p>       
     <p>Copyright &copy; 2015-2015 Travel Comunity. All Rights Reserved.</p> 
     <p><a href="">使用旅游社区网必读</a> &nbsp;旅游社区网版权所有</p>
   </div>
  </div> 
</div>
    
</body>
</html>