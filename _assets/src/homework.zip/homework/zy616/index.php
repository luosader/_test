<?php
header("Content-Type:text/html;charset=UTF-8");
// error_reporting(0);
// date_default_timezone_set("PRC");

//转换文件大小
function realsize($size){
	$size = $size ? $size : 0;
	if($size > 1073741824) {
		$size = round($size / 1073741824 , 2).' GB';
	} elseif($size > 1048576) {
		$size = round($size / 1048576 , 2).' MB';
	} elseif($size > 1024) {
		$size = round($size / 1024 , 2).' KB';
	} else {
		$size = $size . ' Byte';
	}
	return $size;
}

//检测当前目录值
$dir = isset($_POST['path'])?$_POST['path']:(isset($_GET['path'])?$_GET['path']:false);
if($dir===false){
	$dir = dirname(__FILE__);
}
$dir = realpath(str_replace('\\','/',$dir));

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<link rel="stylesheet" type="text/css" href="css/icon.css" />
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<title>php高级文件管理</title>

<style type="text/css">
*{margin: 0px;padding: 0px;}
body{background-color: #999;}
.main{width: 900px;height: auto;overflow: hidden;margin: 20px auto;}
.title{float: left; width: 25px;height: auto;overflow: hidden;margin: 80px 10px 0px 50px;padding: 10px 20px;text-align: center;font-family: 'Microsoft Yahei';font-size: 18px;color: #00F;}
.file{ float: left; width: 600px;height: auto;overflow: hidden;margin-left: 30px;margin-top: 50px;padding: 10px;background-color:#EEE; }
.icon-folder{color: #FFE384;}
.icon-file{color: #888;}
a{background-color: #F2D3A8;}
</style>

</head>
<body>
	<div class="main">
		<div class="title">php高级文件管理</div>
		<div class="file">
			<table border="0"  cellpadding="5" cellspacing="0">
				<th width="200" bgcolor="#BBB">文件名</th><th width="200" bgcolor="#CCA">修改日期</th><th width="100" bgcolor="#CAC">类型</th><th width="100" bgcolor="#EEA">大小</th>
				<!-- 检测是文件夹时的输出 -->
				<?php 
				$fso=opendir($dir);
				while ($file=readdir($fso)) {
					$allpath = "$dir/$file";
					$dirtrue = is_dir($allpath);
					if($dirtrue=="1"){
						if($file!=".."&&$file!=".")	{
			                echo "<td><span class='icon-folder' ></span> <a href=\"?path=".urlencode($dir)."/".urlencode($file)."\" >$file</a></td>\n";
							echo "<td align='center'>".date("Y-n-d H:i:s",filemtime($dir))."</td>";
							echo "</tr>\n";

						} else {
							if($file==".."){
								echo "<tr bgcolor=''>";
								echo "<td><a href=\"?path=".urlencode($dir)."/".urlencode($file)."\">//..</a></td>";
								echo "</tr>";
							}
						}
					}
				}
				closedir($fso);
				?>
				<!-- 检测是文件时的输出 -->
				<?php
				$flag_file=0;
				$fso=opendir($dir);
				while ($file=readdir($fso)) {
					$allpath = "$dir\\$file";
					$dirtrue = is_dir($allpath);
					
					if($dirtrue=="0"){
						$flag_file++;
						$lastsave=date("Y-n-d H:i:s",filemtime("$dir/$file"));
						$type = filetype("$dir/$file"); 
						$size = realsize(filesize("$dir/$file"));
						// $f1 = '文件名：'.basename("$dir/$file")."<br>";
						// $f2 = '文件路径：'."$dir/$file"."<br>";
						// $f3 = "<hr>";
						// $f4 = fopen("$dir/$file", 'r');
						// $str = fgets($f4);
						// $all = '$f1'.'$f2'.'$f3'.'$str';
						// $f1 = '文件名：'.basename($file)."<br>";
						// $f2 = '文件路径：'.$file."<br>";
						// $f3 = "<hr>";
						// $f4 = fopen($file, 'r');
						// $str = fgets($f4);
						// $all = $f1.$f2.$f3.$str;
						// fclose($file);

						echo "<td>";
						echo "<span class='icon-file'> </span>";											
				        echo "<a target='_blank' href=\"".$file."\">".$file."</a>";							
						echo "</td>";
						echo "  <td align='center'>$lastsave</td>\n";
						echo "  <td align='center'>$type</td>\n";
						echo "  <td align='right'>$size</td>\n";
						echo "</tr>";
					 }
				}
				closedir($fso);
				?>
			</table>
		</div>
	</div>
</body>
</html>