<?php
header('Content-Type:text/html;charset=UTF-8');
// 一个文件操作示例

$path = "zy616.txt";
$a = '文件名：'.basename($path)."<br>";
$b = '文件路径：'.$path."<br>";
$c = "<hr>";
$file = fopen($path, 'r');
$str = '文件内容：'.fgets($file);
echo $a.$b.$c.$str;
fclose($file);
?>

