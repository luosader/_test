<?php
header("Content-Type: text/html; charset=UTF-8");
error_reporting(0);

/* 获取文件大小 */
function getSize($fs)
{
	if($fs<1024)
	return $fs." B";
	elseif($fs>=1024&&$fs<1024*1024)
	return number_format($fs/1024, 2)." KB";
	elseif($fs>=1024*1024 && $fs<1024*1024*1024)
	return number_format($fs/1024*1024, 2)." MB";
	elseif($fs>=1024*1024*1024)
	return number_format($fs/1024*1024*1024, 2)." GB";
}

/* 检测当前目录值 */
$CurrentPath	= $_POST['path']?$_POST['path']:($_GET['path']?$_GET['path']:false);
if($CurrentPath===false)
{
	$CurrentPath	= dirname(__FILE__);
}
$CurrentPath	= realpath(str_replace('\\','/',$CurrentPath));
/* 检查完毕 */
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="css/icon.css" />
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<title>文件管理</title>

<style type="text/css">
.title{margin: 30px auto;width: 150px;font-size: 28px;}
.content {margin-left: 0px;margin-top: 20px;font-family: "宋体";font-size: 12px;}
table {font-family: "宋体";font-size: 20px;text-decoration: none;}
.content1 {color: #003399;font-weight: bold;}
.icon-folder{ color:#A67D3D; font-size: 24px;}
.icon-file-o{color: #666;font-size: 24px;}
input {border-right-width: 0.1mm;border-bottom-width: 0.1mm;border-top-style: none;border-right-style: solid;
	border-bottom-style: solid;border-left-style: none;border-right-color: #CCCCCC;border-bottom-color: #CCCCCC;}
</style>

</head>
<body>
	<div class="title">文件管理</div>
	<div class="content">
		<table width="770" border="0" align="center" cellpadding="5" cellspacing="0">	
			<tr>
				<td bgcolor="#DDDDDD">
					<table width="100%" height="100%" border="0" cellpadding="5" cellspacing="2" bgcolor="#eee">			
						<tr>
							<td><span class="content1">当前路径：</span><font color=red><?php echo $CurrentPath;?></font></td>
						</tr>
					</table>
				</td>
			</tr>
			<tr>
				<td bgcolor="#DDDDDD">
					<table width="100%" border="0" cellpadding="5" cellspacing="10" bgcolor="#EFEFEF">
						<tr>
							<td><b>文件名</b></td>
							<td><b>修改日期</b></td>
							<td><b>文件大小</b></td>
						</tr>
				<!-- 检测是文件夹时的输出 -->
						<?php 	
						date_default_timezone_set("PRC");  
						$fso=opendir($CurrentPath);
						while ($file=readdir($fso)) {
							$fullpath	= "$CurrentPath/$file";
							$is_dir		= is_dir($fullpath);
							if($is_dir=="1"){
								if($file!=".."&&$file!=".")	{
									echo "<tr bgcolor=\"#EFEFEF\">\n";
					                echo "<td><span class='icon-folder' ></span> <a href=\"?path=".urlencode($CurrentPath)."/".urlencode($file)."\" >$file</a></td>\n";
									echo "<td>".date("Y-n-d H:i:s",filemtime($CurrentPath))."</td>";
									echo "</tr>\n";

								} else {
									if($file=="..")
									{
										echo "<tr bgcolor=\"#EFEFEF\">\n";
										echo "<td><a href=\"?path=".urlencode($CurrentPath)."/".urlencode($file)."\">上级目录</a></td>";

										echo "</tr>\n";
									}
								}
							}
						}
						closedir($fso);
						?>
				<!-- 检测是文件时的输出 -->
						<?php
						$flag_file=0;
						$fso=opendir($CurrentPath);
						while ($file=readdir($fso)) {
							$fullpath	= "$CurrentPath\\$file";
							$is_dir		= is_dir($fullpath);
							
							if($is_dir=="0"){
								$flag_file++;
								$a=filesize("$CurrentPath/$file");
								$size=getSize($a);
								$lastsave=date("Y-n-d H:i:s",filemtime("$CurrentPath/$file"));
								echo "<tr bgcolor=\"#EFEFEF\">\n";
								echo "<td>";
								echo "<span class='icon-file-o'> </span>";											
						        echo "<a href=\"".$file."\">".$file."</a>";							
								echo "</td>";
								echo "  <td>$lastsave</td>\n";
								echo "  <td>$size</td>\n";
								echo "</tr>";
							 }
						}
						?>
					</table>
				</td>
			</tr>
		</table>
	</div>
</body>
</html>