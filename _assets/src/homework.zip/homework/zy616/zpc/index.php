<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	<title>文件夹的学习</title>
	<link href="css/icon.css" rel="stylesheet" />
	<style type="text/css">
   .conction{margin: 0px auto;height: auto;overflow: hidden; margin-top:50px; margin-left: 100px;}
   .icon-folder{ color:#A67D3D; font-size: 24px;}
   .icon-file-o{color: #666;font-size: 24px;}
   .time{margin-right: 50px;}
   .filesize{float: right; margin-right: 300px; }

	</style>



	<script src="js/jquery-1.11.0.min.js"></script>

</head>
<body>
<?php
$dir=dirname(__FILE__);    //获取本文件目录的文件夹地址
$filesnames=scandir($dir);
foreach ($filesnames as $name ) {?>
<div class="conction">
<?php
		if ( $name  !=  "."  &&  $name  !=  ".." ) {
			//判断文件大小，换算成对应单位
				$size1=filesize($name);
				if($size1/1024<1){
					$size=$size1."b";
				}else if($size1/1024/1024<1){
					$size=(intval($size1/1024*100)/100)."kb";
				}else{
					$size=(intval($size1/1024/1024*100)/100)."mb";
				}
			//判断文件类型，并输出相应文件类型
				if(is_dir($name)){
					echo "<span class='icon-folder' id='icon1'></span>";
					$aurl= "<a href=\"".$name."\" >".$name."</a>";					
					echo $aurl . "<br/>";	
				} else {
					echo "<span class='icon-file-o' id='icon2'></span>";
					$aurl= "<a href=\"".$name."\" >".$name."</a>";
					echo $aurl;
					//echo "<div class='time'>".date("Y/m/d h:i,time()")."</div>";
					echo "<div class='filesize'><span class='time'>".date("Y/m/d h:i")."</span><span class='file'>".$size."</span></div>";
					
				}		
		}
		?>
</div>
<?php } ?>
	
</body>
</html>