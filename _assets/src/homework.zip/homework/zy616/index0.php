<?php
header('Content-Type:text/html;charset=UTF-8');
date_default_timezone_set("PRC");
$path = '../zy616';
// $result = is_dir($path);
// if($result !== false)
//     echo '写入成功！'.'<br>';
// else
//     echo '写入失败！'.'<br>';


/*作业616
文件管理系统
1、列出当前文件下面的所有文件和文件夹
列表
	图标（区分文件夹和文件）文件名  如果是文件右边显示大小加上单位
dirname — 获得文件目录路径的目录部分
basename - 获得不带目录的文件名
file_exists — 检查文件或目录是否存在
is_dir — 判断给定文件名是否是一个目录
is_file — 判断给定文件名是否为一个正常的文件
glob — 寻找与模式匹配的文件路径

stat — 给出文件的信息
filesize — 取得文件大小
filetype — 取得文件类型
fileatime — 取得文件的上次访问时间
filemtime — 取得文件修改时间
touch — 设定文件的访问和修改时间
fileowner — 取得文件的所有者
2、点开文件夹，显示该文件夹下面的文件
	列表
		图标（区分文件夹和文件）文件名  如果是文件右边显示大小加上单位
mkdir — 新建目录
rmdir — 删除目录
pathinfo — 返回文件路径的信息
realpath — 返回规范化的绝对路径名
rename — 重命名一个文件或目录
3、点开文件，新的页面显示该文件的全部内容
	内容包括：1）文件名；
			  2）文件路径；XXXX\XXX\xx.xxx
			  3）文件正文内容
readfile — 输出一个文件
unlink — 删除文件
is_executable、is_link、is_readable、is_writable：这四个PHP文件函数分别返回文件是否可执行、是否是链接、是否可读、是否可写。
*/
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>file management</title>
<link rel="shortcut icon" href="img/Cat Portrait(64x64).jpg">
<link rel="stylesheet" type="text/css" href="css/icon.css" />
<script src="js/jquery-1.11.0.min.js"></script>
<style>
.{margin: 0px;padding:0px;}
body{background-color: #999;}
.main{width: 940px;height: auto;overflow: hidden;margin:0px auto; padding: 10px 20px;background-color: #EEE;}
.file{float:left;width: 940px;height: auto;overflow: hidden;padding: 10px 20px;}
table{margin-left: 55px;}
a{margin-left: 5px;text-decoration: none;}
</style>
<script type="text/javascript" language="javascript">

</script>
</head>
<body>
	<div class="main">
		<div class="file"><!-- 1、列出当前文件下面的所有文件和文件夹  -->
			<table class="" border="1" >
				<th >文件名</th><th>类型</th><th>大小</th><th>最近访问日期</th><th>修改日期</th>
				<?php foreach (glob ( "*" ) as $path) {?>
	            <tr class="filetr" >
	                <td width="150" class="icon-file-text" align=""><?php echo "&nbsp".$path ?></td>
	                <td width="100" align="center"><?php echo filetype($path) ?></td>
	                <td width="100" align="center"><?php echo round((filesize($path)/1024),1).'KB' ?></td>
	                <td width="200" align="center"><?php echo date('Y-m-d H:i:s',fileatime($path)) ?></td>
	                <td width="200" align="center"><?php echo date('Y-m-d H:i:s',filemtime($path)) ?></td>
	            </tr>
	            <?php } ?>
			</table>
		</div><!-- 1、列出当前文件下面的所有文件和文件夹  -->

		<div class="file"><!-- 2、点开文件夹，显示该文件夹下面的文件  -->
			<span class="icon-list" ><a href="http://localhost:9080/php/img/zy616b.php ">img</a> <?php   ?></span>
		</div><!-- 2、点开文件夹，显示该文件夹下面的文件  -->

		<div class="file"><!-- 3、点开文件，新的页面显示该文件的全部内容  -->
			<span class="icon-file" ><a target="_blank" href="http://localhost:9080/php/zy616.txt ">zy616.txt</a> </span>
		</div><!-- 3、点开文件，新的页面显示该文件的全部内容  -->
	</div>

</body>
</html>