<?php
header("Content-Type: text/html; charset=UTF-8");
error_reporting(0);

/* 检测当前目录值 */
$dir = $_POST['path']?$_POST['path']:($_GET['path']?$_GET['path']:false);
if($dir===false){
	$dir = dirname(__FILE__);
}
$dir = realpath(str_replace('\\','/',$dir));

/* 
 * 检查完毕 
 * 循环目录
*/
$flag_file=0;
$fso=opendir($dir);
while ($file=readdir($fso)) {
	$allpath = "$dir\\$file";
	$dirtrue = is_dir($allpath);
	
	if($dirtrue=="0"){
		$flag_file++;
		// $f1 = '文件名：'.basename("$dir/$file")."<br>";
		// $f2 = '文件路径：'."$dir/$file"."<br>";
		// $f3 = "<hr>";
		// $f4 = fopen("$dir/$file", 'r');
		// $str = fgets($f4);
		// $all = '$f1'.'$f2'.'$f3'.'$str';
		$f1 = '文件名：'.basename($file)."<br>";
		$f2 = '文件路径：'.$file."<br>";
		$f3 = "<hr>";
		$f4 = fopen($file, 'r');
		$str = fgets($f4);
		$all = $f1.$f2.$f3.$str;
		echo $all;
	 }
}
closedir($fso);
?>
