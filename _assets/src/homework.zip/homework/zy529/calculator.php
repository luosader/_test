<?php
header('Content-Type:text/html;charset=UTF-8');
//var_dump($_POST['num1']);
//var_dump($_POST['fuhao']);
//var_dump($_POST['num2']);
//var_dump($_POST['num3']);
//echo "string";die;//die到此为止，后面的统统不运行
$fs1 = $_POST['num1'];
$fuhao = $_POST['fuhao'];
$num2 = $_POST['num2'];//以POST方式发送的,不能用$_GET接收。
if ($fuhao == '1') {
	echo($fs1+$num2);
}elseif ($fuhao == '2') {
	echo $fs1-$num2;
}elseif ($fuhao == '3') {
	echo $fs1*$num2;
}elseif ($fuhao == '4') {
	echo $fs1/$num2;
}elseif ($fuhao == '5') {
	echo $fs1%$num2;
}
?>