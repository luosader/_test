<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>JS注册中心_图片验证码点击刷新</title>
<link href="css/icon.css" rel="stylesheet" />
<script src="js/jquery-1.11.0.min.js"></script>
<!--CSS-->
<style type="text/css">
*{margin:0px;padding:0px;font-family:"Microsoft yahei";font-size:12px;}
/*html,body,div,form,a,p,span,input,img{margin:0px;padding:0px;font-family:"Microsoft yahei";font-size:12px;}*/

body{background:url(img/bg_body_res.jpg) no-repeat top;}
.main{width:600px;height:auto;overflow:hidden;margin:0px auto;}
/*顶部制作*/
.head{float:left;width:600px;height:50px;margin-top:10px;}
.loginnow{float:right;color:#FFF;font-size:18px;text-decoration:none;line-height:50px;}
.loginnow:hover{color:#009241;}
.loginnow span{font-size:20px;}
#showDate{float:right;font-size:14px;color:blue;margin-top:50px;margin-left:237px;position:absolute;}
/*内容制作之注册选项*/
.register{float:left;width:600px;height:auto;overflow:hidden;min-height:560px;background-color:#FFF;margin:50px 0px;}
.title{float:left;width:600px;height:60px;}
.reg-style{float:left;width:298px;height:30px;padding:15px 0px;cursor:pointer;}
.style-left{border-right:2px solid #16ADEC;}
.style-right{border-left:2px solid #16ADEC;}
.register-title-img{margin-left:100px;float:left;display:block;background:url('img/user_res.png');}
.register-mobile{width:20px;height:30px;background-position:-0px -0px;}/*选取背景图片上的具体位置图标，不同于引用“icon.css”*/
.register-email{margin-top:4px;width:28px;height:22px;background-position:-20px -0px;}
.register-title-name{margin-left:5px;height:15px;padding:6px 0px;float:left;font-family:"Microsoft yahei","宋体",Arial;font-size:14px;}
/*内容制作之表单制作*/
.register-div{float:left;width:600px;height:auto;overflow:hidden;}
form{width:320px;height:auto;overflow:hidden;margin:0px auto;padding-top:40px;}
.input-div{float:left;width:318px;height:58px;border:1px solid #CCC;border-radius:3px;margin-bottom:20px;}
/*表单制作之短信验证码*/
.getverify-div{float:left;width:398px;height:38px;margin-bottom:20px;}
.getverify{float:left;background:url(img/user_res.png);background-position:-0px -168px;width:142px;height:38px;line-height:38px;text-align:center;}
.getverify:hover{background-position:-144px -168px;cursor:pointer;}
.getverify-link{display:block;width:142px;height:38px;}
.getverify-info{display:none;width:142px;height:38px;color:#666;barckground-color:#D7EEFF;cursor:no-drop;}
.getverify-span{display:none;float:right;line-height:38px;font-size:12px;position:absolute;margin-left:150px;}
.getverify-span a{color:#06F;}
/*表单制作之每一列输入框*/
input{float:left;width:170px;height:30px;padding-left:20px;border-left:1px solid #CCC;font-family:"Microsoft yahei";font-size:16px;background:none;border:none;margin:14px 1px;}
.aa{float:left;width:25px;height:20px;margin:19px;background:url('img/user_res.png');}
.register-icon{float:left;width:25px;height:20px;margin:19px;background:url('img/user_res.png');}
.register-icon-phone{background-position:-4px -32px;}
.register-icon-phone-click{background-position:-4px -52px;}/*当鼠标指向时显示变化，JS触发*/
.register-icon-verify{background-position:-54px -32px;}
.register-icon-verify-click{background-position:-54px -52px;}
.register-icon-pwd{background-position:-77px -32px;}
.register-icon-pwd-click{background-position:-77px -52px;}
.register-icon-yespwd{background-position:-103px -32px;}
.register-icon-yespwd-click{background-position:-103px -52px;}
.register-icon-email{background-position:-125px -32px;}
.register-icon-email-click{background-position:-125px -52px;}
.check{display:none;}
.register-true{display:none;background-position:-21px -75px;}
.register-false{background-position:-175px -28px;}

.verify-div{float:left;width:320px;height:40px;margin-bottom:20px;}
.image-verify{float:left;width:218px;height:38px;border:1px solid #CCC;border-radius:3px;}
.icon-file-image-o{float:left;margin:14px;color:#CCC;}
.varify-input{float:left;width:150px;height:30px;margin-top:4px;border-left:1px solid #CCC;font-family:"Microsoft yahei";font-size:16px;background:none;border:none;}
.verify-img{float:left;margin-left:5px;margin-top:5px;}

/*表单制作之输入框右侧提示*/
.ts-1-div{display:none;width:250px;height:auto;overflow:hidden;min-height:60px;position:absolute;margin:-1px 0px 0px 325px;}
.ts-1-s{float:left;display:block;width:10px;height:10px;margin:20px 0px 0px 3px;border-width:1px;border-style:hidden hidden solid solid;position:absolute;transform:rotate(45deg);}/*border几种表达形式。position设置绝对位置，以便让下面的div上来*/
    /*{
    -moz-transform:rotate(45deg);  火狐
    -webkit-transform:rotate(45deg);  谷歌
    -o-transform:rotate(45deg);  欧朋
    filter:progid:DXImageTransform.Microsoft.BasicImage(rotation=1);  微软IE
    transform:rotate(45deg);  CSS3 改变旋转45角度
  }*/
.ts-2-div{float:left;width:224px;height:auto;overflow:hidden;min-height:30px;margin-left:8px;padding:8px 5px;}
.ts-2-s{float:left;background:url('img/user_res.png');width:16px;height:16px;}

.ts-p{float:right;width:200px;height:auto;overflow:hidden;}
/*-内容制作之注册按钮-*/
.input-submit{width:320px;height:auto;overflow:hidden;margin:0px auto;}
.button{float:left;width:320px;height:50px;border-radius:3px;background-color:#3FA8CD;color:#FFF;font-family:"Microsoft yahei";font-size:18px;border:none;cursor:pointer;}/*border:none取消边框*/
.button:hover{background-color:#6CCBEC;color:#FFF;}

</style>
<!--JS-->
<script type="text/javascript">
//获取系统时间并自动刷新
	$(function(){ 
	setInterval("getTime();",1000); //每隔一秒执行一次 
	}) 
	//取得系统当前时间 
	function getTime(maDate){ 
	var myDate = new Date(); 
	var str = myDate.toLocaleString(); 
	str += "&nbsp&nbsp"+"星期";
	 switch (myDate.getDay()){
	case 0:str += "日";break;
	case 1:str += "一";break;
	case 2:str += "二";break;
	case 3:str += "三";break;
	case 4:str += "四";break;
	case 5:str += "五";break;
	case 6:str += "六";break;
  }
	$("#showDate").html(str); //将值赋给div 
	} 
//注册选项卡
	function tagDiv(tag){
		for(var i=1;i<=2;i++){
			if(tag=="[object Event]"){ tag=1};
			if(i == tag){
			  	document.getElementById('tag'+tag).style.display="block";
				document.getElementById('reg'+tag).style.backgroundColor="#FFF";
			}else{
				document.getElementById('tag'+i).style.display="none";
				document.getElementById('reg'+i).style.backgroundColor="#D7EEFF";	
			}
		}
	}
	window.onload=tagDiv;
//jQuery  $(function(){});
	$(function(){
		//点击input时边框和图标变色(得到焦点)
		jQuery.fn.sr = function(old,nnew,name){
			$(this).css("color","#06f");//输入框字体色
			$(this).parent(".input-div").css("border","1px solid #06f");//大框（div）边界样,等同于$(this).parent(".input-div").css({"color":"#06f","border":"1px solid #06f"});
			$(this).parent('.input-div').children(".register-icon").removeClass(old).addClass(nnew);//小图标
			$(this).parent(".input-div").css({"border":"1px solid #06f","background-color":"#FFF"});//大框（div）背景色样式
			$(this).parent('.input-div').children(".check").css("display","block");//为block时，点input框右侧出现图标？？？
			$(this).parent('.input-div').children(".aa").css("display","none");
			$(this).nextAll(".ts-1-div").css("display","block");
			$(this).nextAll(".ts-1-div").children(".ts-1-s").css({"border-color":"#06f","background-color":"#D7EEFF"});
			var ts = $(this).nextAll(".ts-1-div").children(".ts-2-div");
			ts.css({"border":"1px solid #06f","background-color":"#D7EEFF"});
			ts.children(".ts-2-s").css("background-position","-75px -79px");
			ts.children(".ts-p").css("color","#06f");
			switch(name){
				case 1:ts.children(".ts-p").text("请输入大路地区手机号码（暂不支持港澳及国外地区台）");break;
				case 2:ts.children(".ts-p").text("请输入手机收到的验证码（6位数字）");break;
				case 3:ts.children(".ts-p").text("请输入新密码，要求6-16位，且由字母（区别大小写）、数字、特殊符组成");break;
				case 4:ts.children(".ts-p").text("请确认您的密码");break;
				case 5:ts.children(".ts-p").text("请输入您的邮箱，格式：xxx@sina.com。");break;
				case 6:ts.children(".ts-p").text("请输入邮箱收到的验证码（6位数字）");break;
			}
		};   //$(this)=当前节点，当前元素
		    //$(function(){jQuery.fn.tagDiv = function(){}}) （说明：fn=function || tag=标记 || ）
		
		//点击input时边框和图标变色(失去焦点）
		jQuery.fn.srw = function(old,nnew){
			$(this).css("color","#000");
			$(this).prev(".register-icon").removeClass(nnew).addClass(old);//prev前面的
			if($(this).val() == ""){
			$(this).parent(".input-div").css("border","1px solid #ccc");//多余的？？？
			$(this).nextAll(".ts-1-div").css("display","none");
			//$(this).next(".ts-div").css("display","none");
			}else{
				$(this).inputCheck();
			}
		};
		//JS输入验证
		jQuery.fn.inputCheck = function(){
			var input1 = $(this).val();
			//alert(inputcont.replace(/\s/g,""));
			var input2 = input1.replace(/\s/g,"");//正则\s非打印字符
			//var rel = true;
			//if(rel){
			//if(!(input2 == 18812345678)){
			//if(input2 == 11111111111){
			if((!(input2==13000000000)) && (input2!="")){				
				$(this).parent(".input-div").children(".check").css("display","block").removeClass("register-false").addClass("register-true");
				$(this).parent(".input-div").css("border","1px solid #009241");
				$(this).nextAll(".ts-1-div").css("display","none");
				return true;
			}else{
				$(this).parent(".input-div").css({"border":"1px solid #F00","background-color":"rgb(255,226,226)"});
				$(this).parent(".input-div").children(".check").css("display","block").removeClass("register-true").addClass("register-false");
				
				$(this).nextAll(".ts-1-div").children(".ts-1-s").css({"border-color":"#F00","background-color":"rgb(255,226,226)"});
				var ts = $(this).nextAll(".ts-1-div").children(".ts-2-div");
				ts.css({"border":"1px solid #f00","background-color":"rgb(255,226,226)"});
				ts.children(".ts-2-s").css("background-position","-50px -79px");
				ts.children(".ts-p").css("color","#F00");
				return false;
			}
		};
		//短信验证
		jQuery.fn.getverify = function(){
			$(this).css("display","none");
			$(".getverify-info").css("display","block").text("正在发送");
			//$(this).next(".getverify-info").css("display","block");
			var s=6;
			function sec(){
				//var s=60;不可放在里面，否则重复调用
				s--;
				$(".getverify-info").text("验证码已发送("+s+")");//单引号无效
				if(s==3){
					$(".getverify-span").css("display","block");
				}
				if(s==0){
					clearInterval(time);//停止当前计时器时间，使s不自减了
					$(".getverify-info").css("display","none");
					$(".getverify-link").css("display","block").text("重新发送验证码");
					$(".getverify-span").css("display","none");
				}
			//setInterval("sec();",1000);错误的
			}
			var time = setInterval(function(){sec();},1000);//倒计时的实现 1000毫秒即1秒 调用sec函数
			//setInterval(function(){sec();},1000);//也可以，但是计时器为0时不停止，负数一直减
		};
		//JS手机号空格隔开
		jQuery.fn.phoneInput = function(){
			
			var val = $(this).val();
			var len = $(this).val().length;
			if(len==3||len==9){
				 $(this).val(val+"  ");
			}
			
		};
		//短信验证起作用条件
		jQuery.fn.checkGetVerify = function(){
		var rel = $(".phone").inputCheck();//
			if(rel){
				$(".getverify-link").attr("onClick","$(this).getverify()");
			}else{
				$(".getverify-link").attr("onClick","");
				$(".getverify-link").attr("onClick","$(this).checkGetVerify()");
				$(".getverify-link").attr("onClick",function(){
					$(".phone").focus();
				});//attr改变事件属性值
			}
		}
		//密码验证
		 jQuery.fn.pwd = function(){
			var pwd1 = $(this).parent(".input-div").prev(".input-div").children("#pwd1").val();//var pwd1 = $("#pwd1").val();
			var pwd2 = $(this).val();
			if(pwd1 == pwd2){
				
			}else{
				$(this).parent(".input-div").css({"border":"1px solid #F00","background-color":"rgb(255,226,226)"});
				$(this).parent(".input-div").children(".check").css("display","block").removeClass("register-true").addClass("register-false");
				
				$(this).nextAll(".ts-1-div").children(".ts-1-s").css({"border-color":"#F00","background-color":"rgb(255,226,226)"});
				var ts = $(this).nextAll(".ts-1-div").children(".ts-2-div");
				ts.css({"border":"1px solid #f00","background-color":"rgb(255,226,226)"});
				ts.children(".ts-2-s").css("background-position","-50px -79px");
				ts.children(".ts-p").css("color","#F00");
			}
		}
	});

	function reloadcode(){
		var verify=document.getElementById('safecode');
		verify.setAttribute('src','verify.php?'+Math.random());
	}

	function reloadverify(){
		var verify=document.getElementById('safeverify');
		verify.setAttribute('src','verify.php?'+Math.random());
	}
	
</script>

</head>

<body>
	<div class="main">
    	<div class="head"><!--head0-->
        	<img alt="logo" src="img/logo-2.png" title="旅游社区" />
            <a class="loginnow" href="">我已注册，现在去登录&nbsp;<span class="icon-arrow-circle-o-right"></span></a>
            <!---->
			<span id="showDate">正在获取系统时间......</span>
        </div><!--head1-->
        
    	<div class="register"><!--register0-->
        	<div class="title">
            	<div id="reg1" onClick="tagDiv(1)" class="reg-style style-left">
            		<span class="register-title-img register-mobile"></span>
                    <span class="register-title-name">手机注册</span>
            	</div>
                <div id="reg2" onClick="tagDiv(2)" class="reg-style style-right"><span class="register-title-img register-email"></span> <span class="register-title-name">邮箱注册</span></div>
            </div>
            
            <div id="tag1" class="register-div">
            	<form action="" method="post">
                    <div class="input-div">
                       <span class="register-icon register-icon-phone"></span>
                       <input class="phone" type="text" name="" maxlength="15" placeholder="手机号" onFocus="$(this).sr('register-icon-phone','register-icon-phone-click',1);" onBlur="$(this).srw('register-icon-phone','register-icon-phone-click');" onkeyup="$(this).phoneInput();" />
                       <!--onkeydown是按下的时候触发的，这个时候键值没有输出来。onkeyup是按键抬起的时候执行的，这个时候键值已经有了。和按多长时间没关系，比如你给输入框加这2个事件：<input type="text" id="test1" onkeydown="alert(this.value);"/><input type="text" id="test2" onkeyup="alert(this.value);"/>-->
                       <span class="aa check"></span>
                       <div class="ts-1-div">
                         <span class="ts-1-s"></span>
                         <div class="ts-2-div">
                           <span class="ts-2-s"></span>
                           <p class="ts-p"></p>
                         </div>
                       </div>
                    </div>
                    <div class="getverify-div">
                    	<div class="getverify">
                        <a class="getverify-link" onClick="" onmousedown="$(this).checkGetVerify()">免费获得验证码</a>
                        <span class="getverify-info"></span>
                        </div>
                        <span class="getverify-span">还没收到短信？ 试试<a href="javascript:tagDiv(2)">邮箱注册>></a></span>
                    </div>
                    <div class="input-div">
                       <span class="register-icon register-icon-verify"></span>
                       <input type="text" name="" placeholder="短信验证码" onFocus="$(this).sr('register-icon-verify','register-icon-verify-click',2);" onBlur="$(this).srw('register-icon-verify','register-icon-verify-click');" />
                        <span class="aa check"></span>
                       <div class="ts-1-div">
                         <span class="ts-1-s"></span>
                         <div class="ts-2-div">
                           <span class="ts-2-s"></span>
                           <p class="ts-p"></p>
                         </div>
                       </div>
                    </div>
                    <div class="verify-div">
                    	<div class="image-verify">
							<span class="icon-file-image-o"></span>
							<input class="varify-input" type="text" name="" placeholder="图片验证码" onFocus="$(this).sr('register-icon-verify','register-icon-verify-click');" onBlur="$(this).srw('register-icon-verify','register-icon-verify-click');" />
                    	</div>
						<img class="verify-img" src="verify.php" id="safecode" onclick="reloadcode()" alt="看不清，换一张" />
                    </div>
                    
                    <div class="input-div">
                       <span class="register-icon register-icon-pwd"></span>
                       <input id="pwd1" type="password"  placeholder="密码" onFocus="$(this).sr('register-icon-pwd','register-icon-pwd-click',3);" onBlur="$(this).srw('register-icon-pwd','register-icon-pwd-click');" />
                        <span class="aa check"></span>
                        <div class="ts-1-div">
                         <span class="ts-1-s"></span>
                         <div class="ts-2-div">
                           <span class="ts-2-s"></span>
                           <p class="ts-p"></p>
                         </div>
                       </div>
                    </div>
                    <div class="input-div">
                       <span class="register-icon register-icon-yespwd"></span>
                       <input id="pwd2" type="password"  placeholder="确认密码" onFocus="$(this).sr('register-icon-yespwd','register-icon-yespwd-click',4);" onBlur="$(this).srw('register-icon-yespwd','register-icon-yespwd-click');$(this).pwd();" />
                       <span class="aa check"></span>
                       <div class="ts-1-div">
                         <span class="ts-1-s"></span>
                         <div class="ts-2-div">
                           <span class="ts-2-s"></span>
                           <p class="ts-p"></p>
                         </div>
                       </div>
                    </div>
                </form>
            </div>
            



             <div id="tag2" class="register-div">
            	<form action="" method="post">
                    <div class="input-div">
                       <span class="register-icon register-icon-email"></span>
                       <input type="text" name="" placeholder="邮箱" onFocus="$(this).sr('register-icon-email','register-icon-email-click',5);" onBlur="$(this).srw('register-icon-email','register-icon-email-click');" />
                       <span class="aa check"></span>
                       <div class="ts-1-div">
                         <span class="ts-1-s"></span>
                         <div class="ts-2-div">
                           <span class="ts-2-s"></span>
                           <p class="ts-p"></p>
                         </div>
                       </div>
                    </div>
                    <div class="getverify-div">
                    	<div class="getverify">获取验证码</div>

                        <span class="getverify-span">还没收到邮件？ 试试<a href="javascript:tagDiv(1)">手机注册>></a></span>
                    </div>
                    <div class="input-div">
                       <span class="register-icon register-icon-verify"></span>
                       <input type="text" name="" placeholder="邮箱验证码" onFocus="$(this).sr('register-icon-verify','register-icon-verify-click',6);" onBlur="$(this).srw('register-icon-verify','register-icon-verify-click');" />
                        <span class="aa check"></span>
                       <div class="ts-1-div">
                         <span class="ts-1-s"></span>
                         <div class="ts-2-div">
                           <span class="ts-2-s"></span>
                           <p class="ts-p"></p>
                         </div>
                       </div>
                    </div>
                    <div class="verify-div">
                    	<div class="image-verify">
							<span class="icon-file-image-o"></span>
							<input class="varify-input" type="text" name="" placeholder="图片验证码" onFocus="$(this).sr('register-icon-verify','register-icon-verify-click');" onBlur="$(this).srw('register-icon-verify','register-icon-verify-click');" />
                    	</div>
						<img class="verify-img" src="verify.php" id="safeverify" onclick="reloadverify()" alt="看不清，换一张"/>
                    </div>
                    <div class="input-div">
                       <span class="register-icon register-icon-pwd"></span>
                       <input id="pwd1" type="password"  placeholder="密码" onFocus="$(this).sr('register-icon-pwd','register-icon-pwd-click',3);" onBlur="$(this).srw('register-icon-pwd','register-icon-pwd-click');" />
                        <span class="aa check"></span>
                        <div class="ts-1-div">
                         <span class="ts-1-s"></span>
                         <div class="ts-2-div">
                           <span class="ts-2-s"></span>
                           <p class="ts-p"></p>
                         </div>
                       </div>
                    </div>
                    <div class="input-div">
                       <span class="register-icon register-icon-yespwd"></span>
                       <input id="pwd2" type="password"  placeholder="确认密码" onFocus="$(this).sr('register-icon-yespwd','register-icon-yespwd-click',4);" onBlur="$(this).srw('register-icon-yespwd','register-icon-yespwd-click');$(this).pwd();" />
                       <span class="aa check"></span>
                       <div class="ts-1-div">
                         <span class="ts-1-s"></span>
                         <div class="ts-2-div">
                           <span class="ts-2-s"></span>
                           <p class="ts-p"></p>
                         </div>
                       </div>
                    </div>
                </form>
            </div>
            
            <div class="input-submit">
            	<button class="button" type="submit">立即注册</button>
            </div>
            
        </div><!--register1-->
    </div>
</body>
</html>
