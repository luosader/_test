<?php
//添加水印
	header('Content-Type:image/gif');//文本类型
	$font = dirname(__FILE__).'./font/Amerika_Sans.ttf';// 外部字体路径
	$text = "This";

	$width = 90;//图片宽度
	$height = 30;//图片高度

	$num = 4;//验证码个数
	$fontsize = 20;//字体大小
	$fontx = 1;//文字初始x轴位置
	$fonty = 23;//文字初始y轴位置
	$margin = 22;//

	//创建图像并填充
	$img = imagecreatetruecolor ($width,$height);//新建一个真彩色图像 imagecreatetruecolor(width, height)
	$bgcolor = imagecolorallocate($img,mt_rand(130,255),mt_rand(130,255),mt_rand(130,255));//填充背颜色,由三原色构成 imagecolorallocate(image, red, green, blue)
	imagefilledrectangle($img,0,0,$width,$height,$bgcolor);

	$textcolor = imagecolorallocate($img,mt_rand(0,128),mt_rand(0,128),mt_rand(0,128));
	imagefttext($img,$fontsize,mt_rand(-10,10),mt_rand(0,$fontx),$fonty,$textcolor,$font,$text);
	//imagecolortransparent — 将某个颜色定义为透明色 
	//imagecopymerge — 拷贝并合并图像的一部分 
	imagecolortransparent($img);




	imagegif($img);
	imagedestroy($img);



// //为背景图片添加图片水印（位置随机），背景图片格式为jpeg，水印图片格式为gif
// function watermark($filename,$water){
// //获取背景图片的宽度和高度
// list($b_w,$b_h) = getimagesize($filename);
// //获取水印图片的宽度和高度
// list($w_w,$w_h) = getimagesize($water);
// //在背景图片中放水印图片的位置随机起始位置
// $posX = rand(0, ($b_w-$w_w));
// $posY = rand(0, ($b_h-$w_h));
// //创建背景图片的资源
// $back = imagecreatefromjpeg($filename);
// //创建水印图片的资源
// $water = imagecreatefromgif($water);
// //使用imagecopy()函数将水印图片复制到背景图片指定的位置中
// imagecopy($back, $water, $posX, $posY, 0, 0, $w_w, $w_h);
// //保存带有水印图片的背景图片
// imagejpeg($back,$filename);
// imagedestroy($back);
// imagedestroy($water);
// }
// watermark("brophp.jpg", "logo.gif");
?>
