<?php
header('Content-Type:text/html;charset=UTF-8');
//!isset($a) && $a=1;
//?:
//isset函数是检测变量是否设置。说明: isset() 只能用于变量，因为传递任何其它参数都将造成解析错误。若想检测常量是否已设置，可使用宏定义 defined() 函数。
$var = '';if (isset($var)) {print "This var is set so I' will print.";}
$i = "！逻辑非";$j = "&&逻辑与";$k = "||逻辑或";$l=NULL;
echo("<br />".isset($i,$j,$k));
var_dump(isset($i,$j,$k));var_dump(isset($l));
//逻辑运算符  &&逻辑与，相当于电路串联。  ||逻辑或，相当于电路并联。  ！逻辑非，非门

//三目运算使用  表达式 ? 值1:值2;
//理解：如果表达式为真，则输出值1，否则输出值2
$x = 1;$y=2;
$z=$x>$y ? ("下次再见！"):("你好！");echo("<br />"."<b>$z</b>");

$a=10; $b=20;
$c=$a>$b?($a-$b):($a+$b);var_dump($c);

$e = (1>0) ? "1" : '0';var_dump($e);//说明 三目运算符 与下边if语句意思一样
if( 1 < 0 ){$f = "1";}else{$f = "0";}var_dump($f);
?>