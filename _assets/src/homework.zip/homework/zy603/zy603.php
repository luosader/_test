﻿<?php
echo "<table bgcolor='#DDD'>";
	header("Content-Type:text/html;charset=UTF-8");
	$s1="   很捉急   ";
	var_dump($s1);
	echo '<p>'.'用trim语法去除空格'.'</p>';
	var_dump(trim($s1));
	echo"<br>";
	echo "用str_replace方法替换字符"."<br>";
	$s2=trim($s1);
	echo str_replace('很', '非常',trim($s1)).'<br>';
echo "</table>";
?>