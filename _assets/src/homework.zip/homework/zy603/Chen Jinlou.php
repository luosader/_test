<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>函数用法</title>
	<style type="text/css">
	html,p,body{margin: 0px; padding: 0px;}
	div{margin: 30px auto; width: 400px;  padding-left: 20px;}
	p{color:#3af;}
	</style>
</head>
<body>
<div>
<?php

	//header("Content-Type:text/html;charset=UTF-8");
	$str1="   this is a php example    ";
	echo '<p>'.'str1的字符串长度为'.strlen($str1).'</p>';
	var_dump($str1);
	echo '<p>'.'使用trim（）函数后的字符串'.'</p>';
	var_dump(trim($str1));
//------------------------------------------------
	echo '<p>'.'使用str_replace（）函数,用test替换example'.'</p>'.'<br/>';
	$str2=trim($str1);
	echo str_replace('example', 'test',trim($str1)).'<br>';
	echo "<p>".$str2.'中is的首次出现位置'.'</p>';
	echo strpos($str2,'is').'<br>';

	echo '<p>'.$str2.'中is的最后出现位置'.'</p>';
	echo strripos($str2, 'is').'<br>';

	echo '<p>md5加密:"'.$str2.'"</p>';
	echo md5($str2);
?>
</div>	
</body>
</html>

