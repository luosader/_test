﻿<?php
header('Content-Type:text/html;charset=UTF-8');
$str2=" 去除前后空格 ";
echo "方括号中为原始字符串：[".$str2."]<br>";
echo "原始字符串长度：".strlen($str2)."<br>";

$str3=trim($str2);
echo "去掉首尾空格之后的字符串：[".$str3."]<br>";
echo "执行trim()之后的长度：".strlen($str3)."<br>";
?>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <style type="text/css">
	*{margin:0px;padding:0px;}
	form{float:left;margin-left:300px;width:402px;margin-top:100px;}
	textarea{float:left;width:400px;height:200px;}
	#inp-1{float:left;margin-top:10px;width:300px;height:30px;line-height:30px;font-size:16px;text-align:center;}
	#inp-2{float:left;margin-top:10px;width:300px;height:30px;line-height:30px;font-size:16px;text-align:center;}
	.inp-3{float:left;width:80px;height:30px;margin-top:10px;margin-left:18px;color:red;}
	p{float:left;width:400px;height:200px;line-height:30px;border:1px solid #ccc;margin-top:10px;color:#009241;text-indent: 2em;}
    </style>
    <script src="js/jquery-1.11.0.min.js"></script>
</head>

<body>
    <form action="exchange.php" method="post">
      <textarea class="js" name="text1">这是一个简单的示例</textarea>
	  <input id="inp-1" class="js" type="text" name="num1" placeholder="被替换的字">
	  <input id="inp-2" class="js" type="text" name="num2" placeholder="替换为">
	  <input class="inp-3" type="button" value="替换" onclick="$(this).sub()">
	  <p></p>
	</form>

	<script type="text/javascript">
	$(function(){
		jQuery.fn.sub = function(){
			var str = $(".js").map(function(){
			return ($(this).attr("name")+"="+$(this).val());
		}).get().join("&");
		$.ajax({
			type:"POST",//即form中的method
			url:"exchange.php",
			data:str,
			success:function(msg){
			$("p").text(msg);
			//alert(msg);
			}
		});//ajax整体框架
	}
	})
	
	</script>
</body>
</html>