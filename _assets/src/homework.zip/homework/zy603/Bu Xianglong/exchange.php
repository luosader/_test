<?php
header('Content-Type:text/html;charset=UTF-8');
error_reporting(6143);
ini_set("display_errors", "on");
   $str = $_POST['text1'];
   $rep=$_REQUEST['num2'];
   $text=$_POST['num1'];
   
   echo str_replace($text,$rep,$str);
  
?>
