﻿<?php
	header('Content-Type:text/html;charset=UTF-8');
// 1.创建1个类a，只有一个保护属性b，是一个数组。
// 2.当外部给a类对象不存在的属性赋值时，则使用__set方法，将该方法的参数名和参数值，作为键和值对，给b增加一个元素
// 3.若外部调用a类对象不存在的属性时，则使用__get方法，判断b中是否有键名==该方法的参数名，若有则返回值

// class a{
// 	protected $b=array();


// 	public function __set($name,$value){
// 		// echo "__set 参数名：".$name."<br>\n";
// 		// echo "__set 参数值：".$value."<br>\n";
// 		$this->b[$name]=$value;
// 	}
// 	public function __get($name){
// 		if(isset($this->b[$name])){
// 			return $this->b[$name];
// 		}else{
// 			return null;
// 		}
// 	}
// }

// $Orz=new a;
// echo $Orz->x='1';
// echo "<br>\n";
// echo $Orz->y='100';
// echo "<br>\n";
// echo print_r($Orz->b);

//  class a{
// 	public $b=array();
//     //调用不存在的属性时
// 	// public function __get($cName){
// 	// 	echo "用__get调用不存在的属性：".$cName;
// 	// 	echo "<br>\n";
// 	// }
// 	//判断b中是否有键名==该方法的参数名，若有则返回值
// 	public function __get($cName){
// 		if(isset($this->b[$cName])){
// 			return $this->b[$cName];
// 		}else{
// 			return null;
// 		}
// 	}
//     //给不存在的属性赋值时
// 	public function __set($cName,$cValue){
// 		$this->b[$cName]=$cValue;
// 	}
// }

// $a=new a;
// $a->cName=1;
// $a->cValue=2;
// print_r($a->b) ;


class a{
		protected $b=array();
		//给不存在属性赋值时
		public function __set($cname,$cvalue){
			// echo "__set 参数名：".$cname."<br>\n";
			// echo "__set 参数值：".$cvalue."<br>\n";
			$this->b[$cname]=$cvalue;

		}

		//调用不存在属性时
		// public function __get($cname){
		// 	echo "__get 参数名：".$cname."<br>\n";
		// }

		//判断b中值的情况
		public function __get($cname){
			if(isset($this->b[$cname])){
				return  $this->b[$cname];
			}else{
				return  ' ';
			}
		}

	}
	$Orz = new a;
	echo "<br>\n";
	echo $Orz->x='数值';
	echo $Orz->y=100;
	
?>