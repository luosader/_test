<?php
header('Content-Type:text/html;charset=UTF-8');
/*
Duang,Duang,加特效！Duang,Duang,加特效！~~~
*/
echo "<div >";
echo "<table width='400' height='220' border='1' bgcolor='#7FFFD4' align='center'>";
echo "<tr>";echo "<td>";
echo '逆世界'.'<br>';
echo "</td>";echo "<td>";
$str = '逆世界';
for ($a=1; $a<=mb_strlen($str,'utf-8'); $a++){
	echo mb_substr($str,-$a,1,'utf-8');
}
echo "</td>";
echo "<td>";echo "&nbsp";echo "</td>";echo "</tr>";
echo ('<br>'."<br>");
//echo strrev('逆世界','utf-8')."<br>";
echo "<tr>";
echo "<td>";echo 'abcdefg'.'<br>';echo "</td>";
echo "<td>";echo strrev('abcdefg')."<br>";echo "</td>";
$z='abcdefg';
function demo($z){
	return strrev($z);
}
echo "<td>";echo strtoupper(demo($z));echo "</td>";
echo "</tr>";echo "</table>";echo "</div>";
?>