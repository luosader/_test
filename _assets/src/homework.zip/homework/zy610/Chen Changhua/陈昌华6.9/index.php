<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	<title>PHP日期函数练习</title>
	<!-- <meta http-equiv="refresh" content="1"> -->
	<script src="js/jquery-1.11.0.min.js"></script>
	<style type="text/css">
		html,body,div,p,span,a,img,form{margin: 0px;padding: 0px;}
		body{background-color: #ADADAD;}
		.main{width: 900px;height: auto;overflow: hidden;margin: 0px auto;}
		.top{float: left;width: 900px;height: 90px;border-bottom-left-radius: 5px;border-bottom-right-radius: 5px;text-align: center;font: bold 40px "华文中宋";padding-top: 30px;background-image: linear-gradient(to bottom,#FFF,#CFCFCF);border-bottom: 1px solid #AAAAAA;box-shadow: 0px 1px 4px rgba(150,150,150,0.6);color: #696969;position: fixed;top: 0px;z-index: 1;}
		.content{float: left;width: 880px;height: auto;overflow: hidden;min-height: 400px;padding: 10px;background-color: #E6E6FA;border-radius: 5px;margin-top: 150px;color: #575757;}
		.title{float: left;width: 880px;height: 40px;line-height: 40px;font: bold 30px "华文中宋";text-align: center;}
		span{font: 30px "华文中宋";}
		.cont{float: left;width: 880px;height: 200px;margin-top: 30px;}
		.add{float: left;width: 138px;height: 138px;border: 1px solid #ADADAD;border-radius: 100px;margin-top: 30px;margin-left: 370px;cursor: pointer;}
		.add1{background-image: url("image/location_haw.jpg");}
		.add2{background-image: url("image/location_sha.jpg");}
		.add3{background-image: url("image/location_ma.jpg");}
		.add4{background-image: url("image/location_lon.jpg");}
		.wenzi{float: left;width: 100px;height: 20px;line-height: 20px;text-align: center;margin-top: 170px;margin-left: -120px;}
		.time{float: right;width: 298px;height: 58px;line-height:58px;text-align: center;border: 1px solid #ADADAD;margin-top: 70px;margin-right: 55px;border-radius: 10px;background-color: #FFE4E1;display: none;}
		.day{width: 400px;height: 80px;line-height: 80px;text-align: center;margin: 60px auto;font: bold 30px "Microsoft yahei";}
	</style>
	<script type="text/javascript">
		function tag(t){
			if(t == "[object Event]"){
				t =1;
			}
			for(var i =1; i<5; i++){
				if(i == t){
					document.getElementById("t"+t).style.display="block";
				}else{
					document.getElementById("t"+i).style.display="none";
				}
			}
		}
	</script>
</head>
<body>
	<div class="main">
		<div class="top">PHP日期函数练习</div>
		<div class="content">
			<div class="title">世界时间<span>(点击获取)</span></div>
			<div class="cont">
				<div class="add add1" id="a1" onclick="tag(1)"></div>
				<div class="time" id="t1">
					<?php
						date_default_timezone_set('US/Hawaii');
						echo '夏威夷时间：';
						echo date('Y-m-d H:i:s D', time());
					?>
				</div>
				<div class="wenzi">夏威夷</div>
			</div>
			<div class="cont">
				<div class="add add2" id="a2" onclick="tag(2)"></div>
				<div class="time" id="t2">
					<?php
						date_default_timezone_set('Asia/Shanghai');
						echo '上海时间：';
						echo date('Y-m-d H:i:s D', time());
					?>
				</div>
				<div class="wenzi">上海</div>
			</div>
			<div class="cont">
				<div class="add add3" id="a3" onclick="tag(3)"></div>
				<div class="time" id="t3">
					<?php
						date_default_timezone_set('Etc/GMT-5');
						echo '马尔代夫时间：';
						echo date('Y-m-d H:i:s D', time());
					?>
				</div>
				<div class="wenzi">马尔代夫</div>
			</div>
			<div class="cont">
				<div class="add add4" id="a4" onclick="tag(4)"></div>
				<div class="time" id="t4">
					<?php
						date_default_timezone_set('Europe/London');
						echo '伦敦时间：';
						echo date('Y-m-d H:i:s D',time());
					?>
				</div>
				<div class="wenzi">伦敦</div>
			</div>
			<div class="cont">
				<div class="day">
					<?php
					$date1 = date('Y-m-d H:i:s', time());
					$time1 = strtotime($date1);
					$time2 = mktime(0,0,0,1,15,2016);
					$sub = intval(($time2-$time1)/60/60/24);
					echo "距离还款日还有："."<font color=#FF4040>".$sub."</font>"."天";
				?>
				</div>
			</div>
		</div>
	</div>
</body>
</html>