<?php
   header('content-Type: text/html; charset=UTF-8');
   
   $atm = $_POST['oo'];
   

   echo $atm."时间:";
   switch ($atm) {
     case '伦敦':
     $a = "Europe/London";
       break;
     case '斯德哥尔摩':
     $a = "Europe/Stockholm";
       break;
     case '开罗':
     $a = "Africa/Cairo";
       break;
     case '重庆':
     $a = "Asia/Chongqing";
       break;
     case '东京热':
     $a = "Asia/Tokyo";
       break;
     case '夏威夷':
     $a = "America/Havana";
       break;
     case '纽约':
     $a = "America/New_York";
       break;
     case '里约热内卢':
     $a = "America/Rio_Branco";
       break;              
     
   }
     

  
   date_default_timezone_set($a);
   echo date('Y-m-d H:i:s ',time());


?>