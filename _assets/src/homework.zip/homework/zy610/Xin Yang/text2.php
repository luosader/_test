<?php
   header('content-Type: text/html; charset=UTF-8');
   

 $abc = $_POST['dajj'];                  
 $a=mktime(0,0,0,1,15,2016);
 $b=time();
 $c=$a-$b;
 echo '距离您的还款日还有'.intval($c/3600/24).'天'.date("H小时i分钟s秒",$c);

                    


  

  


   
?>