<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	<title>时间与日期</title>
	<!--<meta http-equiv="refresh" content="1">-->
	<script src="js/jquery-1.11.0.min.js"></script>
	<script type="text/javascript">
  var timerID = null;
  var hours = <?php $a = time();
    $b = strtotime('2016-1-15 0:0:0');
    $d = strtotime('1970-1-2 0:0:0');
    $c = ($b - $a)+$d;echo date('H',$c); ?>;
   var minutes = <?php $a = time();
    $b = strtotime('2016-1-15 0:0:0');
    $d = strtotime('1970-1-2 0:0:0');
    $c = ($b - $a)+$d;echo date('i',$c); ?>;;
   var seconds = <?php $a = time();
    $b = strtotime('2016-1-15 0:0:0');
    $d = strtotime('1970-1-2 0:0:0');
    $c = ($b - $a)+$d;echo date('s',$c); ?>;
   var day = <?php $a = time();
    $b = strtotime('2016-1-15 0:0:0');
    $d = strtotime('1970-1-2 0:0:0');
    $c = ($b - $a)+$d;echo date('z',$c); ?>;

  function startclock () 
  {
  var timeValue = "" 
    timeValue += day+"天 ";
    timeValue += hours;
    timeValue += ((minutes < 10) ? ":0" : ":") + minutes;
    timeValue += ((seconds < 10) ? ":0" : ":") + seconds;
    document.clock.thetime.value = timeValue;
    timerID =  window.setInterval(showtime,1000);
  }
  function showtime () {
     seconds --;
     if(seconds < 0){
     	minutes--;
     	seconds =00;
     	seconds = 59;
     }
     if(minutes < 0){
     	hours--;
     	minutes = 59;
     }
      if(hours < 0){
     	day--;
     	hours = 59;
     }

     var timeValue = "" ;
     timeValue += day+"天 ";
    timeValue += hours;
    timeValue += ((minutes < 10) ? ":0" : ":") + minutes;
    timeValue += ((seconds < 10) ? ":0" : ":") + seconds;
    document.clock.thetime.value = timeValue;
  }

</script>
	<style type="text/css">
	.main{
		width: 600px;
		margin: 70px auto;
	}
	.right{
		width: 288px;
		height: 400px;
		float: right;
		color: #c00;
		padding-left: 10px;
		font-size: 18px;
		background-color: #ccc;
		border-left: 1px solid #fff;
	}
	.left{
		width: 258px;
		height: 360px;
		float: left;
		padding: 20px;
		font-size: 16px;
		color: #009241;
		background-color: #ccc;
	}
	input{
		width: 160px;
		background-color: #ccc;
		margin-left: 55px;
	}

	</style>
</head>
<body onload=startclock();  onload=ff(); >	
<div class="main">
<p style="font-size:26px; text-align:center;">时间与日期作业</p>
<div class="right">
<p>距离&nbsp;<span style="color:#009241;"><?php $b = strtotime('2016-01-15 00:00:01');
    echo '2016-01-15 00:00:01';
    $e = date('w',$b);
    switch ($e) {
    	case '0':echo "星期日";break;
    	case '1':echo "星期一";break;
    	case '2':echo "星期二";break;
    	case '3':echo "星期三";break;
    	case '4':echo "星期四";break;
    	case '5':echo "星期五";break;
    	default:echo "星期六";break;
    }?></span>&nbsp;&nbsp; 还有：</p>
<form name="clock">
<input name="thetime" style="border:0px none;color: #009241;font-size: 22px; " />
</form>
	</div>
	<div class="left">
	<script type="text/javascript">


window.setInterval(,1000);
</script>
	<?php   echo "上海时区";
	      echo "<br>";
	      date_default_timezone_set("Asia/shanghai");
	      echo date('Y-m-d H:i:s',time());
	      echo "<br>";
	      echo "<br>";
	      echo "巴黎(法国首都)时区";
	      echo "<br>";
	      date_default_timezone_set("Europe/Paris");
	      echo date('Y-m-d H:i:s',time());
	      echo "<br>";
	      echo "<br>";
	      echo "纽约时区";
	      echo "<br>";
	      date_default_timezone_set("America/New_York");
	      echo date('Y-m-d H:i:s',time());
	      echo "<br>";
	      echo "<br>";
	      echo " 堪培拉(澳大利亚的首都)时区";
	      echo "<br>";
	      date_default_timezone_set("Australia/Canberra");
	      echo date('Y-m-d H:i:s',time());
	      echo "<br>";
	      echo "<br>";
	      echo "比绍(几内亚比绍首都)时区";
	      echo "<br>";
	      date_default_timezone_set("Africa/Bissau");
	      echo date('Y-m-d H:i:s',time());
	      echo "<br>";
	      echo "<br>";
	      echo "塔那那利佛(马达加斯加的首都)时区";
	      echo "<br>";
	      date_default_timezone_set("Indian/Antananarivo");
	      echo date('Y-m-d H:i:s',time());
	 ?>

 </div>
 </div>
</body>
</html>