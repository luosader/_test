<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>LXphp:time</title>
<script src="js/jquery-1.11.0.min.js"></script>
<style>
	body{
		width:700px;
		height:auto;
		margin:60px auto;
		font-size:20px;
	}
	.main{
		float:left;
		width:696px;
		height:auto;
		border:2px solid #666;
		background:#3A3A3A;
		border-radius:50px;
	}
	.interior{
		float:left;
		width:572px;
		height:300px;
		border:4px solid #444;
		background:#555;
		padding:10px;
		margin:60px 0px 0px 50px;
		}	
	.top{
		float:left;
		width:400px;
		height:160px;
		padding:20px 50px 0px 50px;
		margin:0px 0px 10px 36px;
		border:2px solid #eee;
		}
	.div1{
		float:left;
		width:400px;
		height:100px;
		line-height:100px;
		text-align:center;
		font-size:60px;
		color:#fff;
		}
	.div2{
		float:left;
		width:400px;
		height:60px;
		line-height:60px;
		text-align:center;
		font-size:24px;
		color:#fff;
		}		
	.bottom{
		float:left;
		width:500px;
		height:100px;
		margin-left:36px;
		border:2px solid #eee;
		line-height:100px;
		text-align:center;
		font-size:30px;
		color:#fff;
		}	
	.button{
		float:left;
		width:572px;
		height:50px;
		padding:25px 10px 0px 10px;
		margin:10px 0px 20px 36px;
		}
	.input{
		float:left;
		width:40px;
		height:40px;
		font-size: 16px;
		font-weight: 700;
		border-radius:20px;
		margin-left:70px;
		padding:0px;
		background: #555;
		color: #fff;
		}			
</style>
</head>
<body>
	<div class="main">
    	<div class="interior">
        	<div class="top">
            	<div class="div1"></div>
            	<div class="div2"></div>
            </div>
        	<div class="bottom">
            </div>
        </div>
        <div class="button">
        	<input class="input" type="button" value="+12" onClick="$(this).time()">
          	<input class="input" type="button" value="+8" onClick="$(this).time()">
        	<input class="input" type="button" value="+2" onClick="$(this).time()">
        	<input class="input" type="button" value="-4" onClick="$(this).time()">
        	<input class="input" type="button" value="-10" onClick="$(this).time()">
      </div>
    </div>	


<!--**********************-->	
    <script>
    	$(function(){
			
			jQuery.fn.time=function(){
				var time="time="+$(this).val();
				jQuery.fn.timet=function(){
					$.ajax({
						type:"post",
						url:"LXphp3.php",
						data:time,
						success: function(a){
							$(".div1").text(a);
							}
						});
					$.ajax({
						type:"post",
						url:"LXphp31.php",
						data:time,
						success: function(a){
							$(".div2").text(a);
							}
						});
					$.ajax({
						type:"post",
						url:"LXphp32.php",
						data:time,
						success: function(a){
							$(".bottom").text(a);
							}
						});
	
					}
				setInterval(function(){$(this).timet()},1000);	
				}
		window.onload=$(this).time();		
		});
    </script>
</body>
</html>
