<?php
    header('Content-Type: text/html; charset=UTF-8');
    $time=$_POST["time"];
    $b="香港(中国)";
    $a="Asia/Hong_Kong";
    switch($time){
    	case "+12":
			$b="富纳富提(太平洋)";
            $a="Pacific/Funafuti";
    		break;
     	case "+8":
			$b="香港(中国)";
            $a="Asia/Hong_Kong";
			break;
    	case "+2":
			$b="斯德哥尔摩(欧洲)";
            $a="Europe/Stockholm";
    		break;
    	case "-4":
			$b="圣地亚哥(美洲)";
            $a="America/Santiago";
    		break;
    	case "-10":
 			$b="拉罗汤加(太平洋)";
            $a="Pacific/Rarotonga";
   		    break;
    	default:break;
   }
   date_default_timezone_set($a);
    echo date('Y-m-d ').substr("日一二三四五六",3*date("w"),3)." ".$b;
	/*date_default_timezone_set("Pacific/Funafuti");
	echo date('Y/m/d H:i:s ').'富纳富提(太平洋)';
	echo "<hr>";
	date_default_timezone_set("Asia/Hong_Kong");
	echo date('Y/m/d H:i:s ').'香港(中国)';
	echo "<hr>";
	date_default_timezone_set("Europe/Stockholm");
	echo date('Y/m/d H:i:s ')."斯德哥尔摩(欧洲)";
	echo "<hr>";
	date_default_timezone_set("America/Santiago");
	echo date('Y/m/d H:i:s ').'圣地亚哥(美洲)';
	echo "<hr>";
	date_default_timezone_set("Pacific/Rarotonga");
	echo date('Y/m/d H:i:s ').'拉罗汤加(太平洋)';*/
?>
