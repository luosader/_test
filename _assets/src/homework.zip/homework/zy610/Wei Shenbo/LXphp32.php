<?php
	header('Content-Type: text/html; charset=UTF-8');
	$aa=$_POST["time"];
	$mktime=mktime(0,0,0,1,15,2016);
	//var_dump(mktime(0,0,0,1,15,2016));
	//var_dump(time());
	//echo date("N",mktime(0,0,0,1,15,2016))."<br>";
	//echo mktime(0,0,0,1,15,2016)."<br>";
	//echo time()."<br>";
	$t=$mktime-time();
	$daynum=$t/(60*60*24);
	echo "距".date(" Y-m-d ",$mktime).substr("日一二三四五六",3*date("w",$mktime),3)." 还有 ".ceil($daynum)." 天";
?>
