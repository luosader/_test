<?php
header('Content-Type:text/html;charset=UTF-8');
echo "<table width='400' bgcolor='#EEE'>";
date_default_timezone_set("Etc/GMT+8");//unix时间戳 格林威治时间 1970-1-1至今的秒数 时区：中国,东八区;还可以在页头设置 ini_set("date.timezone","Asis/shanghai");第三种：php配置文件中查找 php.ini date.timezone = PRC
echo "<tr height='50'>"."<td>";
echo "西八区：";echo "</td>";echo "<td>";
echo date('Y-m-d H:i:s');echo "</td>"."</tr>";

date_default_timezone_set("America/New_York");
echo "<tr height='50'>"."<td>";
echo "America/New_York：";echo "</td>";echo "<td>";
echo date('Y-m-d H:i:s');echo "</td>"."</tr>";

date_default_timezone_set("Canada/Atlantic");
echo "<tr height='50'>"."<td>";
echo "Canada/Atlantic：";echo "</td>";echo "<td>";
echo date('Y-m-d H:i:s');echo "</td>"."</tr>";

date_default_timezone_set("UTC");
echo "<tr height='50'>"."<td>";
echo "协调世界时：";echo "</td>";echo "<td>";
echo date('Y-m-d H:i:s');echo "</td>"."</tr>";

date_default_timezone_set("Atlantic/Madeira");
echo "<tr height='50'>"."<td>";
echo "Atlantic/Madeira：";echo "</td>";echo "<td>";
echo date('Y-m-d H:i:s');echo "</td>"."</tr>";

date_default_timezone_set("Africa/Gaborone");
echo "<tr height='50'>"."<td>";
echo "Africa/Gaborone：";echo "</td>";echo "<td>";
echo date('Y-m-d H:i:s');echo "</td>"."</tr>";

date_default_timezone_set("PRC");
echo "<tr height='50'>"."<td>";
echo "People's Republic of China：";echo "</td>";echo "<td>";
echo date('Y-m-d H:i:s');echo "</td>"."</tr>";

date_default_timezone_set("Pacific/Nauru");
echo "<tr height='50'>"."<td>";
echo "Pacific/Nauru：";echo "</td>"."<td>";
echo date('Y-m-d H:i:s');echo "</td>"."</tr>";

echo "<tr height='50'>"."<td>"."</td>"."</tr>";;

date_default_timezone_set("Etc/GMT-8");
echo "<tr height='50'>"."<td align='center'>";
echo '现在是：'.date('Y-m-d h:i:s');
echo "</td>"."<td align='center'>";
$a=strtotime("January 15 2016");
$b=ceil(($a-time())/60/60/24);
echo "距离2016年1月15日还有：".$b."天。";
echo "</td>"."</tr>";




echo "</table>";
/*
获取至少四个时区的时间
美国、马尔代夫、

算出一段时间内的天数
算出今天距离xx还剩xx天(2016-1-15)

算出还款哪一天，算出哪天星期几

*/


?>