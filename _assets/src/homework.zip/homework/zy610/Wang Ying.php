<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	<meta http-equiv="refresh" content="1"/>
	<title>zuoye</title>
</head>
<script src="js/jquery-1.11.0.min.js"></script>
<script>
$(function(){
	$("body").attr('style','text-align:center;padding-top:50px');
	$("span").attr('style','color:blue;margin-bottom:20px');
	$(".pp").attr('style','color:red;font-family:微软雅黑;font-size:50px;width:100px;margin:0px auto');
	$(".span1").attr('style','color:blue;font-size:20px');

	
});
</script>
<body>

<?php
 header('content-Type: text/html; charset=UTF-8');
 function tt($zone){
 	
 	date_default_timezone_set($zone);
    echo date('Y:m:d H:i:s',time());
 };
echo "<span>这是上海时间:</span>";
tt('Asia/Shanghai');
echo "<br>";
echo "<span>这是纽约时间:</span>";
tt('America/New_York');
echo "<br>";
echo "<span>这是柏林时间:</span>";
tt('Europe/Berlin');
echo "<br>";
echo "<span>这是南乔治亚岛时间:</span>";
tt('Atlantic/South_Georgia');
echo "<hr>";
?>
 
 <span class="span1">距离还款日还有:</span>;
 <span class="pp">
 <?php
 date_default_timezone_set('Asia/Shanghai');
 $t=date('z');
 //var_dump($t);die;
$yu=(365-$t-1+15);
echo $yu;
?>	
 </span>
 <span class="span2">天</span>
</body>
</html>	