<?php
	header('Content-Type:text/html;charset=UTF-8');
	class F{
		//属性
		private $name;
		private $sex;
		var $age=1;
		const PI=3.14;


		//方法
		//构造方法
		// public function __construct($name,$sex,$age){
		// 	$this->name=$name;
		// 	$this->sex=$sex;
		// 	$this->age=$age;
		// }
        //业务逻辑

        public function f1(){
        	return $this->age = 11;
        }
		//析构函数
		// public function __destruct(){
			
		// }
	}
	/**
	* 子类（子承父业）
	*/
	class C extends F
	{
		function c1(){
			return $this->f1();
		}
	}

	$p = new C;
	echo $p->age;
	echo '<br/>';
	echo $p->f1();
	echo '<br/>';
	echo $p->c1();
	echo '<br/>';

	Class Person{
		// 定义常量
		const country = "中国";

		public function myCountry() {
		    //内部访问常量
		    echo "我是".self::country."人<br />";
		}
	}

	// 输出常量
	echo Person::country."<br />";

	// 访问方法
	$p1 = new Person();
	$p1 -> myCountry();

?>