<?php
header('Content-Type:text/html;charset=UTF-8');

//定义一个数组，改变其中一个元素的值
echo '定义一个数组，改变其中元素的值'.'<hr>';
$string = array('张三丰','男','20','未婚');
echo  '修改前：'.implode ( '; ' ,  $string). "<br>" ;
$replace = array('顺','男','23');
$start = array( 3 ,  0 ,  0 );
$length  = array( 6 ,  3 ,  2 );
echo  '修改后：'.implode ( '; ' ,  substr_replace ( $string ,  $replace ,  $start ,  $length ));
/*

*/
?>