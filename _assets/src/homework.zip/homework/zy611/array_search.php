<?php
header('Content-Type:text/html;charset=UTF-8');
//三维数组取值  查找x行x列的内容
$num1 = $_POST['num1'];
$num2 = $_POST['num2'];
$num3 = $_POST['num3'];
//$a = $num1 + 1;
//$b = $num2 + 1；
//$c = $num3 + 1;
$array = array(array(array('艾希','盖伦','瑞兹'),array('薇恩','希维尔','凯特琳'),array('潘森','雷克顿','奥拉夫')),array(array('亚索','劫','艾克'),array('卡特琳娜','阿卡利','乐芙兰'),array('伊芙琳','雷恩加尔','魔腾')),array(array('塞恩','慎','内瑟斯'),array('阿里斯塔','拉莫斯','崔斯特'),array('娑娜','迦娜','基兰')),);
if ($num1 != ''&&$num2 != ''&&$num3 != '') {
	echo $array[$num1][$num2][$num3];
}else{echo 'error！';}
/*
if ($num1 != ''&&$num2 != ''&&$num3 != '') {
	echo $array[$num1][$num2][$num3];
}else if($num1>=0 &&$num1<=2&&$num2>=0&&$num2<=2&&$num3>=0&&$num3<=2&&){
	echo '请输入0~2之间的数！';
}else{echo 'error！';}
*/
/*
//isset($num1)

*/
?>