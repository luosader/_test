<?php
	header('Content-Type:text/html;charset=UTF-8');
// 1.建立一个abstract（抽象）类（EG:动物类）
// 2.在新建一个具体的某种动物的类继承抽象类（例如刚刚的动物类）
// 3.在新建的具体动物类里面实例化抽象方法，例如有的动物是走的，有的是飞的等等
// 4.实例化具体的动物类，并且调用这些方法
// 5.加成分，熟练使用构造函数和析构函数
	abstract class animal{
		private $desc;
		public $classify;
		// abstract function eat($tag){echo '吃法';}
		abstract public function eat();
		//构造函数
		public function __construct(){
			echo "<br>";
			echo "分类："; 
		}
		public function set($desc){
			// $this->set=$set;
			echo "描述：";
			echo $this->desc = $desc;
		}
		//析构函数
		public function __destruct(){}
	}

	class dolphin extends animal{
		public function __construct(){
			parent::__construct();
			echo "水生，"; 
		}
		function eat(){echo '食肉。';}
		function desc($desc){$this->set($desc);}
	}
	class bear extends animal{
		public function __construct(){
			parent::__construct();
			echo "陆地，"; 
		}
		function eat(){echo '杂食。';}
		function desc($desc){$this->set($desc);}
	}
	class bee extends animal{
		public function __construct(){
			parent::__construct();
			echo "空中，"; 
		}
		function eat(){echo '食素。';}
		function desc($desc){$this->set($desc);}
	}

	$dolphin = new dolphin;
	$dolphin->eat();
	$dolphin->desc('海豚 （学名：Delphinidae）生活在海洋中的鲸目哺乳动物。');

	$bear = new bear;
	$bear->eat();
	$bear->desc('熊（英文名称：Bears）。熊科杂食性大型哺乳动物。');

	$bee = new bee;
	$bee->eat();
	$bee->desc('蜜蜂（Bee/Honey bee）属膜翅目、蜜蜂科。昆虫纲动物。');
?>