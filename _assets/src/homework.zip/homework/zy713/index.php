<?php
	header('Content-Type:text/html;charset=UTF-8');

	class Aname{
		// private $namefile='只能是字符串';
		// private $namefile=file("allname_category.txt");
		private $num=1;
		// private $surnames = $namefile[0];
		// private $fnames1 = $namefile[1];
		// private $fnames2 = $namefile[2];
		// private $mnames1 = $namefile[3];
		// private $mnames2 = $namefile[4];

		protected function _initialize(){

		}

		//构造方法
		public function __construct(){
			$namefile=file("allname_category.txt");
			$this->surnames=$namefile[0];
			$this->fnames1=$namefile[1];
			$this->fnames2=$namefile[2];
			$this->mnames1=$namefile[3];
			$this->mnames2=$namefile[4];
		}

		public function getAll(){
			$a=array();
			$a['surnames']=$this->surnames;
			$a['fname']=$this->fname;
			return $a;
		}

		//生成姓氏字符串
		private function createsur(){			
			//百家姓
			$surnames="刘";
			// $surnames=$this->surnames;
			$num=mt_rand(1,ceil(strlen($surnames)/3));
			$surname=mb_substr($surnames,$num-1,1,'utf-8');
			return $surname;
		}

		//生成女名字符串
		private function cteateFname(){
			//
			$num1=mt_rand(1,ceil(strlen($this->fnames1)/3));
			$fsingle=mb_substr($this->fnames1,$num1-1,1,'utf-8');
			$num2=mt_rand(1,ceil(strlen($this->fnames2)/6))*2;
			$fdouble=mb_substr($this->fnames2,$num2-2,2,'utf-8');

			$n=rand(1,2);
			if($n==1){
				$fname=$fsingle;
			}else{
				$fname=$fdouble;
			}
			return $fname;
		}
		//生成男名字符串
		private function cteateMname(){
			//
			$num1=mt_rand(1,ceil(strlen($this->mnames1)/3));
			$fsingle=mb_substr($this->mnames1,$num1-1,1,'utf-8');
			$num2=mt_rand(1,ceil(strlen($this->mnames2)/6))*2;
			$fdouble=mb_substr($this->mnames2,$num2-2,2,'utf-8');

			$n=rand(1,2);
			$mname = ($n==1)?$fsingle:$fdouble;
			return $mname;
		}

		//获取姓氏
		public function getSur(){
			return $this->createsur();
		}
		////设置姓氏
		//public function setSur($surname){
		//	$this->surname=$surname;
		//}

		//获取女性名字
		function getFname(){
			return $this->cteateFname();
		}
		////设置名字
		//public function setName($fname){
		//	$this->name=$fname;
		//}
		//获取男性名字
		function getMname(){
			return $this->cteateMname();
		}
	}
	$gname = new Aname();
	// print_r($gname->getSur());
	echo '姓名大全(姓氏从百家姓中获取)';
	echo '<br/>';
	echo "<table width=300 height=40 border=1>";
	echo "<tr align=center>"."<td width=100 height=40>";
	echo '<strong>'.'<em>'.'百家姓'.'</em>'.'</strong>';
	echo '</td>'."<td width=100 height=40>";
	echo '女名';
	echo '</td>'."<td width=100 height=40>";
	echo '男名';
	echo '</td>';
	echo '</tr>';

	echo "<tr align=center>"."<td width=100 height=40>";
	echo '姓名';
	echo '</td>'."<td width=100 height=40>";
	echo $gname->getSur();
	echo $gname->getFname();
	echo '</td>'."<td width=100 height=40>";
	echo $gname->getSur();
	echo $gname->getMname();
	echo '</td>';
	echo '</tr>';
	//echo '<br/>';
	//$gname->setSur('汪');
	//var_dump($gname->getAll());
	//echo $gname->getFname();
	//echo '<br/>';
	//echo$gname->getSur();
	echo "</table>"

?>