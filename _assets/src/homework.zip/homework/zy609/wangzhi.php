<?php
header('Content-Type:text/html;charset=UTF-8');
$subject = $_POST['num4'];
$pattern = "/http:\/\/(www|bbs)(.*?)(com|net)/";
$replace = "[网址]";
print_r(preg_replace($pattern, $replace, $subject));

?>
