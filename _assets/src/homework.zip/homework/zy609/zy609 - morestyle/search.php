<?php
header('Content-Type:text/html;charset=UTF-8');
$cont1 = $_POST['text1'];
$cz1 = $_POST['num1'];
$pcre = "/$cz1/";//子模式(www|bbs) ; .*? 是非贪婪匹配

if($s=preg_match_all($pcre, $cont1, $zf2)){
	echo '共查找到'.$s.'个'.'"'.$cz1.'"。'."\n";
	print_r($zf2);
}else if($cz1 == ""){
	echo "请输入查找内容！";
}else{echo "未查找到相应的字符！";}

?>