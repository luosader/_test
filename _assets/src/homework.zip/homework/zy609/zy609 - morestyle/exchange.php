<?php
header('Content-Type:text/html;charset=UTF-8');
$cont2 = $_POST['text2'];
$cz2 = $_POST['num2'];
$th = $_POST['num3'];

$pattern = "/$cz2/";
if(preg_match_all($pattern, $cont2) != 0){
	print_r(preg_replace($pattern, $th, $cont2));
}else if($cz2 == ""){
	echo "请输入待替换内容！";
}else if($th == ""){
	echo "请输入替换内容！";
}else{echo "您要替换的字符串不存在！";}

?>