<?php
header('Content-Type:text/html;charset=UTF-8');
$cont2 = $_POST['text2'];
$cz2 = $_POST['num2'];
$th = $_POST['num3'];

$pattern = "/$cz2/";
if(preg_match_all($pattern, $cont2) != 0){
	print_r(preg_replace($pattern, $th, $cont2));
}else if($cz2 == ''){
	echo "请输入待替换内容！";
}else if($th == ''){
	echo "请输入替换内容！";
}else{echo "您要替换的字符串不存在！";}

// \d数字[0-9] \D非数字[^0-9] 
// \w字 [a-z][^A-Z][0-9] \W非字 [^a-z][^A-Z][^0-9][^_]
// \s空白字符 空格，回车，垂直制表符  \S除了以上 的非空白字符
// \h水平空白字符 \H非水平空白字符 \v垂直空白字符 \V非垂直空白字符
// \f换页 \n换行 \r回车 \t水平制表符 \G
// . all

?>