<?php
/**
 * WincomtechPHP
 * --------------------------------------------------------------------------------------------------
 * 版权所有 2013-2035 XXX网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.wowlothar.cn
 * --------------------------------------------------------------------------------------------------
 * 这不是一个自由软件！您只能在遵守授权协议前提下对程序代码进行修改和使用；不允许对程序代码以任何形式任何目的的再发布。
 * 授权协议：http://www.wowlothar.cn/license.html
 * --------------------------------------------------------------------------------------------------
 * Author: Lothar
 * Release Date: 2015-10-16
 */

/**
 * +----------------------------------------------------------
 * 手机版
 * +----------------------------------------------------------
 */
$_LANG['catalog'] = 'Site Maps';
$_LANG['m_guestbook_title'] = 'Please enter the message subject';
$_LANG['m_guestbook_name'] = 'Please enter the contact';
$_LANG['m_guestbook_contact_type'] = 'Please enter the Contact type';
$_LANG['m_guestbook_contact'] = 'Please enter the Contact';
$_LANG['m_guestbook_content'] = 'Please enter the Content';
$_LANG['m_captcha'] = 'Please enter the Captcha';

// 手机版提示
$_LANG['m_dou_msg_cue'] = "If you don't make a choice, will be in d% seconds after the jump to a page";
?>