<?php
/**
 * WincomtechPHP
 * --------------------------------------------------------------------------------------------------
 * 版权所有 2013-2035 XXX网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.wowlothar.cn
 * --------------------------------------------------------------------------------------------------
 * 这不是一个自由软件！您只能在遵守授权协议前提下对程序代码进行修改和使用；不允许对程序代码以任何形式任何目的的再发布。
 * 授权协议：http://www.wowlothar.cn/license.html
 * --------------------------------------------------------------------------------------------------
 * Author: Lothar
 * Release Date: 2015-06-10
 */

// 案例中心
$_LANG['case_category'] = 'Case';
$_LANG['case_tree'] = 'Case Category';
$_LANG['case_news'] = 'Case';
$_LANG['case_more'] = 'More Case';
$_LANG['case_previous'] = 'Previous';
$_LANG['case_next'] = 'Next';
$_LANG['case_description'] = 'Case Description';
$_LANG['case_content'] = 'Case Content';

?>