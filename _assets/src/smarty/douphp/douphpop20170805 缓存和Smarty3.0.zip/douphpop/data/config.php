<?php
$dbhost   = "localhost";
$dbname   = "douphpop";
$dbuser   = "root";
$dbpass   = "root";
$prefix   = "dou_";

// $dbhost   = "localhost";
// $dbname   = "douphp";
// $dbuser   = "root";
// $dbpass   = "root";
// $prefix   = "dou_";

// charset
define('DOU_CHARSET','utf-8');

// administrator path
define('ADMIN_PATH','admin');

// mobile path
define('M_PATH','m');


?>
