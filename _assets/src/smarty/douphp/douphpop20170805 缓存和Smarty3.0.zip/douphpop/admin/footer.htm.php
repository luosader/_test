<?php
/* Smarty version 3.1.30, created on 2017-08-05 12:07:04
  from "D:\WWW\_svn\_op\douphpop\admin\templates\footer.htm" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5985446825b954_56997932',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f4937a88db26325116c3ccae4d52f20504dff1d9' => 
    array (
      0 => 'D:\\WWW\\_svn\\_op\\douphpop\\admin\\templates\\footer.htm',
      1 => 1499653077,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5985446825b954_56997932 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="clear"></div>
<div id="dcFooter">
 <div id="footer">
  <div class="line"></div>
  <ul>
   <?php echo $_smarty_tpl->tpl_vars['lang']->value['footer_copyright'];?>

  </ul>
 </div>
</div><!-- dcFooter 结束 -->
<div class="clear"></div><?php }
}
