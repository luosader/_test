<?php
/* Smarty version 3.1.30, created on 2017-08-05 12:07:04
  from "D:\WWW\_svn\_op\douphpop\admin\templates\ur_here.htm" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5985446824fdd3_23125084',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9ef6350bb8f5108c366e82fed911ad8071133177' => 
    array (
      0 => 'D:\\WWW\\_svn\\_op\\douphpop\\admin\\templates\\ur_here.htm',
      1 => 1499653078,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5985446824fdd3_23125084 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!-- 当前位置 -->
<div id="urHere"><?php echo $_smarty_tpl->tpl_vars['lang']->value['home'];
if ($_smarty_tpl->tpl_vars['ur_here']->value) {?><b>></b><strong><?php echo $_smarty_tpl->tpl_vars['ur_here']->value;?>
</strong> <?php }?></div><?php }
}
