<?php
/* Smarty version 3.1.30, created on 2017-08-05 12:07:04
  from "D:\WWW\_svn\_op\douphpop\admin\templates\header.htm" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_598544681ee342_90760036',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3991a9de75173d20c31391c094227511faa246d7' => 
    array (
      0 => 'D:\\WWW\\_svn\\_op\\douphpop\\admin\\templates\\header.htm',
      1 => 1501745264,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_598544681ee342_90760036 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div id="dcHead">
 <div id="head">
  <div class="logo"><a href="index.php"><img src="images/dclogo.gif" alt="logo"></a></div>
  <div class="nav">
   <ul>
    <li class="M"><a href="JavaScript:void(0);" class="topAdd"><?php echo $_smarty_tpl->tpl_vars['lang']->value['top_add'];?>
</a>
     <div class="drop mTopad"><?php if ($_smarty_tpl->tpl_vars['lang']->value['top_add_product']) {?><a href="product.php?rec=add"><?php echo $_smarty_tpl->tpl_vars['lang']->value['top_add_product'];?>
</a><?php }?> <?php if ($_smarty_tpl->tpl_vars['lang']->value['top_add_article']) {?><a href="article.php?rec=add"><?php echo $_smarty_tpl->tpl_vars['lang']->value['top_add_article'];?>
</a><?php }?> <a href="nav.php?rec=add"><?php echo $_smarty_tpl->tpl_vars['lang']->value['top_add_nav'];?>
</a> <a href="show.php"><?php echo $_smarty_tpl->tpl_vars['lang']->value['top_add_show'];?>
</a> <a href="page.php?rec=add"><?php echo $_smarty_tpl->tpl_vars['lang']->value['top_add_page'];?>
</a> <a href="manager.php?rec=add"><?php echo $_smarty_tpl->tpl_vars['lang']->value['top_add_manager'];?>
</a> <a href="link.php"><?php echo $_smarty_tpl->tpl_vars['lang']->value['top_add_link'];?>
</a> </div>
    </li>
    <li><a href="../index.php" target="_blank"><?php echo $_smarty_tpl->tpl_vars['lang']->value['top_go_site'];?>
</a></li>
    <li><a href="index.php?rec=clear_cache"><?php echo $_smarty_tpl->tpl_vars['lang']->value['clear_cache'];?>
</a></li>
    
    
   </ul>
   <ul class="navRight">
    <li class="M noLeft"><a href="JavaScript:void(0);"><?php echo $_smarty_tpl->tpl_vars['lang']->value['top_welcome'];
echo $_smarty_tpl->tpl_vars['user']->value['user_name'];?>
</a>
     <div class="drop mUser">
      <a href="manager.php?rec=edit&id=<?php echo $_smarty_tpl->tpl_vars['user']->value['user_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['lang']->value['top_manager_edit'];?>
</a>
      
     </div>
    </li>
    <li class="noRight"><a href="login.php?rec=logout"><?php echo $_smarty_tpl->tpl_vars['lang']->value['top_logout'];?>
</a></li>
   </ul>
  </div>
 </div>
</div>
<!-- dcHead 结束 --><?php }
}
