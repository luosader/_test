<?php
if (!defined('IN_LOTHAR')) die('Hacking attempt');
// 显示除了E_NOTICE(提示)和E_WARNING(警告)外的所有错误
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
// 关闭 set_magic_quotes_runtime
@set_magic_quotes_runtime(0);
// 调整时区
if (PHP_VERSION >= '5.1') date_default_timezone_set('PRC');
if (empty(session_id())) session_start();

// 定义DouPHP基础常量
define('ROOT_PATH', str_replace('include/init.php', '', str_replace('\\', '/', __FILE__)));
define('ROOT_HOST', 'http://' . $_SERVER['HTTP_HOST']);
$root_url = dirname(ROOT_HOST . $_SERVER['PHP_SELF']) .'/';
define('ROOT_URL', !defined('ROUTE') ? $root_url : str_replace('include/', '', $root_url)); // 区分route.php作为入口的情况来分别赋值

if (!file_exists(ROOT_PATH . "data/system.dou")) {
      header("Location: " . ROOT_URL . "install/index.php\n");
      exit();
}

// 载入DouPHP核心文件
require_once (ROOT_PATH . 'data/config.php'); // 伪静态下config.php会在route.php中第一次被调用
require (ROOT_PATH . 'include/smarty/Smarty.class.php');
// require (ROOT_PATH . 'include/smarty/SmartyBC.class.php');// 兼容低版本 无效？
require (ROOT_PATH . 'include/mysql.class.php');
require (ROOT_PATH . 'include/common.class.php');
require (ROOT_PATH . 'include/action.class.php');
require (ROOT_PATH . 'include/check.class.php');
require (ROOT_PATH . 'include/firewall.class.php');
require (ROOT_PATH . 'include/memory.class.php');

// 定义DouPHP其它常量
// DS 在 Smarty 里定义了
// M_PATH ？
define('M_URL', ROOT_URL . M_PATH . '/');

// 实例化DouPHP核心类
$dou = new Action($dbhost, $dbuser, $dbpass, $dbname, $prefix, DOU_CHARSET);
$check = new Check();
$firewall = new Firewall();
$memory = new Memory();
// $memory = new Memory('localhost',11211);

// 定义系统标识
define('DOU_SHELL', $dou->get_one("SELECT value FROM " . $dou->table('config') . " WHERE name = 'hash_code'"));
define('DOU_ID', 'dou_' . substr(md5(DOU_SHELL . 'dou'), 0, 5));

// 读取站点信息
$_CFG = $dou->get_config();
// $GLOBALS['_CFG'] 自动等于 $_CFG ？


/*语言包管理*/
// var_dump(session_id());
if (in_array($_GET['lpost'],array('zh_cn','en_us'))) {
    if (empty($_SESSION['lang_identifier'])) {
        $_SESSION['lang_identifier'] = $_GET['lpost'];
    }
}
// 语言切换
// $GLOBALS['_CFG']['language'] = 'zh_cn';
// $GLOBALS['_CFG']['language'] = 'en_us';
// $GLOBALS['_CFG']['language'] = $_SESSION['lang_identifier'];
// echo $GLOBALS['_CFG']['language'];
// 风格模板
// echo $_CFG['site_theme'];
// $_CFG['site_theme'] = 'default';
// $_CFG['site_theme'] = 'en_us';
// $_CFG['site_theme'] = (!$_SESSION['lang_identifier'] || $_SESSION['lang_identifier']=='zh_cn')?'default':$_SESSION['lang_identifier'];
/*读取 theme/$_CFG[site_theme]/style.css 的头信息
\admin\include\action.class.php      get_theme_info()
\admin\theme.php
$theme_enable = $dou->get_theme_info($_CFG['site_theme']);
$theme_array = $dou->get_subdirs(ROOT_PATH . 'theme/');*/
/*
Theme Name: Default
Theme URI: http://demo.wowlothar.com/
Description: 默认模板
Version: 1.0
Author: Lothar
Author URI: http://www.wowlothar.cn/
*/
// die;


// !EXIT_INIT 网站常规模式， 验证码 captcha.php 中有定义 define('EXIT_INIT', true);
if (!defined('EXIT_INIT')) {
    // 判断是否关闭站点
    if ($_CFG['site_closed']) {
        // 设置页面编码
        header('Content-type: text/html; charset='. DOU_CHARSET);
        echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=". DOU_CHARSET ."\"><div style=\"margin: 200px; text-align: center; font-size: 14px\"><p>" . $_LANG['site_closed'] . "</p><p></p></div>";
        exit();
    }

    // 设置页面缓存和编码
    header('Cache-control: private');
    header('Content-type: text/html; charset='. DOU_CHARSET);

    // 判断是否跳转到手机版（条件：是移动端、没有强制显示PC版、手机版没有关闭）
    if ($dou->is_mobile() && $_COOKIE['client']!='pc' && !$_CFG['mobile_closed']) {
        $mobile_url = str_replace(ROOT_URL, '', 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
        $dou->dou_header(ROOT_URL . M_PATH . '/' . $mobile_url);
    }

    // 豆壳防火墙 ，过滤机制 dou_magic_quotes()
    $firewall->dou_firewall();


    /*
    * 由原版的 2.6 向 3.1 转
    * 是否可写在一块？ smarty.init.php
    */
    // SMARTY配置
    $smarty = new Smarty();
    $smarty->left_delimiter = '{';// 左定界符
    $smarty->right_delimiter = "}";// 右定界符
    $smarty->template_dir = ROOT_PATH . 'theme'. DS . $_CFG['site_theme'];// html模板地址
    $smarty->compile_dir = ROOT_PATH . 'temlpate_c';// 模板编译生成的文件（能让php脚本编译的）
    // $smarty->config_dir = ROOT_PATH . 'configs/';// 指定smarty加载外部配置文件应当存放与此目录下
    $smarty->cache_dir = ROOT_PATH . 'cache';// 缓存（数据库查询、临时数据）
    // 以下是开启缓存的两个必要配置。通常不用smarty的缓存机制。
    $smarty->caching = true;// 开启缓存
    $smarty->cache_lifetime = 60;//缓存时间
    // 如果编译和缓存目录不存在则建立 需要有目录操作权限
    if (!file_exists($smarty->compile_dir)) mkdir($smarty->compile_dir, 0777);
    if (!file_exists($smarty->cache_dir)) mkdir($smarty->cache_dir, 0777);
    /*// Smarty 3.x 系列对象型配置
    $smarty ->setTemplateDir(ROOT_PATH . 'theme'. DS . $_CFG['site_theme']) //设置所有模板文件存放的目录
            // ->addTemplateDir(ROOT_PATH.'templates2/') //可以添加多个模板目录（前后台各一个）
            ->setCompileDir(ROOT_PATH . 'cache') //设置所有编译过的模板文件存放的目录
            // ->setPluginsDir(ROOT_PATH.'plugins/') //设置为模板扩充插件存放的目录
            // ->setConfigDir(ROOT_PATH.'configs')//设置模板配置文件存放的目录
            ->setCacheDir(ROOT_PATH . 'cache'.DS.'data'); //设置缓存文件存放的目录
    // $smarty->caching = false; //设置Smarty缓存开关功能
    // $smarty->cache_lifetime = 60*60*24; //设置模板缓存有效时间段的长度为1天
    $smarty->left_delimiter = '<{'; //设置模板语言中的左结束符
    $smarty->right_delimiter = '}>'; //设置模板语言中的右结束符*/

    /*
    * Smarty 过滤器 ， 改变了原始路径
    * PCRE(正则)：
                /……/ 是开始结束符，\ 是转义符，.匹配任意字符，*重复前面内容
                U 去除贪婪模式，m 多行匹配，s 是让.能匹配换行
    * 虐杀原形：// link后面直接匹配href的，不能随意颠倒顺序
            <script type="text/javascript" src="images/jquery.min.js"></script>
            <link href="style.css" rel="stylesheet" type="text/css" />
            <meta http-equiv=\"Content-Type\" content=\"text/html; charset=". DOU_CHARSET ."\">
    * 原版： function remove_html_comments($source, & $smarty) {}
            & $smarty 起什么作用？
    */
    function remove_html_comments($source) {
        global $_CFG;
        $theme_path = ROOT_URL . 'theme';
        $source = preg_replace('/\"\.*\/images\//Ums', '"images/', $source);
        $source = preg_replace('/\"images\//Ums', "\"theme/$_CFG[site_theme]/images/", $source);
        // $source = preg_replace('/\"\.*\/images\//Ums', "\"theme/$_CFG[site_theme]/images/", $source);// 上两个合并？不成功
        $source = preg_replace('/link href\=\"([A-Za-z0-9_-]+)\.css/Ums', "link href=\"theme/$_CFG[site_theme]/$1.css", $source);
        $source = preg_replace('/\"style\//Ums', "\"theme/$_CFG[site_theme]/style/", $source);// 自定义1
        $source = preg_replace('/link href\=\"style\.css/Ums', "link href=\"theme/$_CFG[site_theme]/style.css", $source);// 自定义2
        $source = preg_replace('/theme\//Ums', "$theme_path/", $source);
        $source = preg_replace('/^<meta\shttp-equiv=["|\']Content-Type["|\']\scontent=["|\']text\/html;\scharset=(?:.*?)["|\'][^>]*?>\r?\n?/i', '', $source);
        return $source = preg_replace('/<!--.*{(.*)}.*-->/U', '{$1}', $source);
    }
    // Smarty用于模板编译的过滤器函数
    // $smarty->register_prefilter('remove_html_comments');// Smarty 2.6
    $smarty->registerFilter('pre','remove_html_comments');// "pre"前置, "post"后置, "output"输出 ，"variable"。
    // $smarty->registerPlugin('function','remove_html_comments','remove_html_comments');// 需要被使用
    // $smarty->register->preFilter('remove_html_comments');// 不存在的
    // $smarty->clearCompiledTemplate('filter.html');//清除编译目录下的编译文件或者指定条件的编译文件。
    /*无法实现？直接忽略注册函数*/
    // $_DPS = array("img"=>"","js"=>"","css"=>"","org"=>"");
    // $smarty->assign('dps',$_DPS);


    // 系统模块
    $_MODULE = $dou->dou_module();
    // 载入模块文件
    foreach ((array)$_MODULE['init'] as $init_file) {
        require ($init_file);
    }
    // 载入语言文件
    foreach ((array) $_MODULE['lang'] as $lang_file) {
        require ($lang_file);
    }
    $_LANG['copyright'] = preg_replace('/d%/Ums', $_CFG['site_name'], $_LANG['copyright']);

    // 如果存在自定义类则载入
    if (file_exists($other_class_file = ROOT_PATH . 'include/other.class.php')) {
          require ($other_class_file);
          $other = new Other();
    }

    // 网站字符集
    $_CFG['dou_charset'] = DOU_CHARSET;
    // 通用信息调用
    $smarty->assign("lang", $_LANG);
    $smarty->assign("site", $_CFG);
    $smarty->assign("url", $_URL = $dou->dou_url()); // 模块URL
    $smarty->assign("open", $_OPEN = $_MODULE['open']); // 模块开启状态
    $_DISPLAY = unserialize($_CFG['display']); // 显示设置
    $_DEFINED = unserialize($_CFG['defined']); // 自定义属性
}

// 开启缓冲区。 ob_end_flush();在哪？\admin\include\cloud.class.php handle()
ob_start();
?>