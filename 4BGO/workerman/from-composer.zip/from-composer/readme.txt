
通过composer安装
composer require workerman/gateway-worker


workerman入门之GatewayWorker的使用
https://blog.csdn.net/qq_33716731/article/details/90137769

GatewayWorker整合web系统开发多人分组在线聊天的步骤
http://www.ptbird.cn/gateway-worker-chat-online-group.html

与ThinkPHP等框架结合
http://doc2.workerman.net/work-with-other-frameworks.html






