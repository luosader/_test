<?php

namespace Wrench;

/**
 * Resource interface
 */
interface Resource
{
    public function getResourceId();
    public function getResource();
}
