.. vim: set tw=78 sw=2 ts=2 :

======
Wrench
======

Wrench is a WebSockets library for PHP 5.3+

.. toctree::
   :maxdepth: 3

   introduction
   installing
   getting-started
   performance
   api/index
   authors

