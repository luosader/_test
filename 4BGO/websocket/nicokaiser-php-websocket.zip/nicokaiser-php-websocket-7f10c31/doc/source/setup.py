#!/usr/bin/env python

from distutils.core import setup

setup(
        name='wrench-documentation',
        version='2.0.0',
        requires=[
            "sphinxcontrib.phpdomain"
        ]
     )
