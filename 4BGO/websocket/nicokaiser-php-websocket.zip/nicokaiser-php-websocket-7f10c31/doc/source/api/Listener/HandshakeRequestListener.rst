------------------------------------------
Wrench\\Listener\\HandshakeRequestListener
------------------------------------------

.. php:namespace: Wrench\\Listener

.. php:class:: HandshakeRequestListener

    .. php:method:: onHandshakeRequest(Connection $connection, $path, $origin, $key, $extensions)

        Handshake request listener

        :type $connection: Connection
        :param $connection:
        :type $path: string
        :param $path:
        :type $origin: string
        :param $origin:
        :type $key: string
        :param $key:
        :type $extensions: array
        :param $extensions:
