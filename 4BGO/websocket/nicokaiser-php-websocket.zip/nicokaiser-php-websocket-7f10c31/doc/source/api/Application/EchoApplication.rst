------------------------------------
Wrench\\Application\\EchoApplication
------------------------------------

.. php:namespace: Wrench\\Application

.. php:class:: EchoApplication

    Example application for Wrench: echo server

    .. php:method:: onData($data, $client)

        :param $data:
        :param $client:
