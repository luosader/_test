:::::::::::::::::
Wrench\\Exception
:::::::::::::::::

.. php:namespace: Wrench\\Exception

.. toctree::

   BadRequestException
   CloseException
   ConnectionException
   Exception
   FrameException
   HandshakeException
   InvalidOriginException
   PayloadException
   RateLimiterException
   SocketException
